#!/usr/bin/python

import sys, os, re, subprocess, string, struct, time, operator, signal, shutil, binascii, mmap
from fnmatch import fnmatch
from datetime import datetime
from xml.etree import ElementTree

# ElementTree seems unaware of XSL namespace
# Unfortunately the syntax to register a namespace changed from
# ElementTree version 1.2 to 1.3, and some older Ubuntu installations
# may still have version 1.2.
XSL_NAMESPACE = "http://www.w3.org/1999/XSL/Transform"
try:
    ElementTree.register_namespace("xsl", XSL_NAMESPACE)
except AttributeError:
    ElementTree._namespace_map[XSL_NAMESPACE] = "xsl"
# Also ElementTree 1.2 doesn't raise its own ParseError exception
# (boooooo).
try:
    ElementTree.XmlParseError = ElementTree.ParseError
except:
    import pyexpat # this is the module that actually does the parsing
    ElementTree.XmlParseError = pyexpat.error
# ALSO.... Element changes from function to class in 1.3 ARGHHH!!!
ElementTree.ElementClass = ElementTree.Element('test').__class__

# 0.1:
#   initial checkin
# 0.2:
#   more or less functional
# 0.3:
#   restructured XML tree adding <trapz> top level tag
#   added version number checking in XML
VERSION = '0.3'

# clean up a str or byte object
# to get rid of zero bytes/characters
def cleanBytesToStr(inB):
  outStr = ''
  if isinstance(inB, str):
    for c in inB:
      if c != '\000':
        outStr = outStr + c
    return outStr
  else:
    for c in inB:
       if c != 0:
           outStr = outStr + chr(c)
  return outStr

def ScrapeProc():
    """Using adb shell, scrape info about running processes from /proc
    Returns (tidName, tidParentPid)
    tidName maps tids to /proc/<pid>/task/<tid>/comm which is a 16 character task name
    tidParentPid maps tid to pid"""
    procScraper = subprocess.Popen(['adb', 'shell',
                                    'for i in /proc/*/task/*/comm; do echo -n $i:; cat $i; done'],universal_newlines=True,
                                   stdout=subprocess.PIPE)

    tidName = {}
    tidParentPid = {}
    for line in procScraper.stdout.readlines():
        m = re.match('/proc/(\d*)/task/(\d*)/comm:(.*?)\n', line)
        if m:
            (pid, tid, name) = m.groups()
            pid = int(pid)
            tid = int(tid)
            tidStr = cleanBytesToStr(name)
            tidName[tid] = tidStr
            tidParentPid[tid] = pid
    return (tidName, tidParentPid)

# MPU watts per core at given OPP -- for OMAP4460
MPU_CORES = 2
# actual PMIC efficiency is probably closer to 0.9 but there are other losses on the board, DRAM, etc... this seems
# to better match our data measured at the battery
PMIC_EFFICIENCY = 0.75
MPU_POWER_BY_OPP = {
    350000000  : 0.27417 / MPU_CORES / PMIC_EFFICIENCY,
    700000000  : 0.57641 / MPU_CORES / PMIC_EFFICIENCY,
    920000000  : 0.95449 / MPU_CORES / PMIC_EFFICIENCY,
    1200000000 : 1.53879 / MPU_CORES / PMIC_EFFICIENCY
}

UnknownHz = dict()

def PowerConsumed(elapsed, hz):
    power = 0

    try:
        power = elapsed / 1E9 * MPU_POWER_BY_OPP[hz]
    except KeyError:
        if hz not in UnknownHz:
            sys.stderr.write('WARNING: Unknown cpu freq %d, power numbers are incorrect!\n' % (hz))
            UnknownHz[hz] = hz

    return power

class TrapzEvent:
    """This provides a handy object interface to a Trapz event."""

    def CategoryToInt(cat):
        try:
            return int(cat)
        except ValueError:
            # may already be preprocessed into names?
            # XXXmunsal I'd like to get rid of this eventually
            return TrapzEvent.NAME_TO_CAT[cat.strip()]

    def ExtraToInt(extra):
        """Python ints are infinite precision. Truncate to 32 bit."""
        return int(extra) & 0xffffffff

    def TimestampToInt(ts):
        """Convert timestamp string to integral type. Timestamp is in decimal
        seconds, we convert to integral nanoseconds."""
        if isinstance(ts, (int, long)):
            # assume we're dealing with nanoseconds already
            return ts

        try:
            (sec,nsec) = ts.split('.')
        except:
            sec = int(ts)
        else:
            # nsec is a string which needs to be zero-padded to 9 digits
            assert len(nsec) <= 9
            nsec += "0"*(9-len(nsec))
            sec = int(sec)
            nsec = int(nsec)
        return sec * 1000000000 + nsec
        
    N_FIELDS = 10
    FIELDS = (TIMESTAMP, SEQ_NUM, CPU, PID, TID,
              CATEGORY, COMPONENT, TRACE, EXTRA1, EXTRA2) = range(N_FIELDS)

    ATTRIBUTES = ("timestamp", "sequence", "cpu", "pid", "tid", "category", "compId", "traceId",
               "e1", "e2", "e3", "e4", "logcat", "catname")

    # these functions convert event strings into native type
    CONVERT = {"timestamp" : TimestampToInt,
               "sequence" : int,
               "cpu" : int,
               "pid" : int,
               "tid" : int,
               "category" : CategoryToInt,
               "compId" : int,
               "traceId" : int,
               "e1" : ExtraToInt,
               "e2" : ExtraToInt,
               "e3" : ExtraToInt,
               "e4" : ExtraToInt,
               "logcat" : str,
               "catname" : str,
               "recType" : int,
               "extraRecCount" : int }

    (CAT_KERNEL, CAT_PLATFORM, CAT_APPS, CAT_LOGCAT, CAT_UNKNOWN) = range(5)

    NAME_TO_CAT = {
        'Kernel' : CAT_KERNEL,
        'Platform' : CAT_PLATFORM,
        'Apps' : CAT_APPS,
        'LogCat' : CAT_LOGCAT,
        }


    CAT_TO_NAME = dict((bar,foo) for (foo,bar) in NAME_TO_CAT.items())

    # These have to be kept in sync with trapz_device.h
    TRAPZ_BUFF_REC_TYPE_MASK = 0x80
    TRAPZ_BUFF_COMPLETE_MASK = 0x40
    TRAPZ_BUFF_CAT_ID_MASK = 0x30
    TRAPZ_BUFF_EXTRA_COUNT_MASK = 0x0f
    TRAPZ_EXTRA_FORMAT_STRING = 2
    STRUCT_MAIN_FORMAT = '<BBBBBBBBHHLL'
    STRUCT_EXTRA_FORMAT = '<BBBBLLLL'
    STRUCT_SIZE = struct.calcsize(STRUCT_MAIN_FORMAT)

    def __setattr__(self, name, value):
        """Automatically convert assignments of event attributes to the
        expected type."""
        try:
            convertedValue = TrapzEvent.CONVERT[name](value)
        except KeyError:
            raise AttributeError
        else:
            self.__dict__[name] = convertedValue

    def __init__(self, event=None, eventExtra=None):
        if isinstance(event, ElementTree.ElementClass):
            # this is an <event> element from an XML parse tree
            for attrib in TrapzEvent.ATTRIBUTES:
                # Here we rely on the fact that our class attribute names match
                # the XML attribute names
                self.__setattr__(attrib, event.get(attrib))
        elif isinstance(event, str):
             # this is a record from a binary TRAPZ file
            self.UnpackFromString(event, eventExtra)
        else:
            # this is a list of values that were in one line of a CSV file
            try:
                # Here we rely on the fact that our class attribute names are in
                # a list with the same order as the CSV values.
                [self.__setattr__(attrib, value) for (attrib, value)
                 in map(None, TrapzEvent.ATTRIBUTES, event)]
            except TypeError:
                # not iterable... leave object empty
                pass

    def __cmp__(self, other):
        return cmp(self.timestamp, other.timestamp)

    def CombinedTraceName(self):
        return str(self.traceId)

    def TraceSignature(self):
        return ( self.category, self.compId, self.traceId )

    def ComponentSignature(self):
        return ( self.category, self.compId )

    def State(self, xml):
        """State name for an event (see scenario.py)"""
        try:
            component = xml.LookupComponent(self)
        except KeyError:
            componentStr = 'C%s' % self.compId
        else:
            componentStr = component.get('name')
        try:
            trace = xml.LookupTrace(self)
        except KeyError:
            traceStr = 'T%s' % self.traceId
        else:
            traceStr = trace.get('name')
        return '%s_%s' % (componentStr, traceStr)
        

    def UnpackFromString(self, s, s2):
        (ctrl, self.sequence, self.e1, self.e2, self.cpu, compTraceId1, compTraceId2, compTraceId3,
         self.pid, self.tid, sec, nsec) = struct.unpack(TrapzEvent.STRUCT_MAIN_FORMAT, s)
        if s2 is not None:
            (ctrl2, counter2, recformat, unused, self.e1, self.e2, self.e3, self.e4) = struct.unpack(TrapzEvent.STRUCT_EXTRA_FORMAT, s2)
        else:
            self.e3 = 0
            self.e4 = 0

        self.timestamp = sec * 1000000000 + nsec
        self.category = ((ctrl & TrapzEvent.TRAPZ_BUFF_CAT_ID_MASK) >> 4)
        self.recType = (ctrl & TrapzEvent.TRAPZ_BUFF_REC_TYPE_MASK)
        self.extraRecCount = (ctrl & TrapzEvent.TRAPZ_BUFF_EXTRA_COUNT_MASK)
        self.compId = (compTraceId1 << 4 | ((compTraceId2 & 0xf0) >> 4))
        self.traceId = (((compTraceId2 & 0x0f) << 8) | compTraceId3)

    def PackToString(self):
        rec2 = None

        ctrl = TrapzEvent.TRAPZ_BUFF_REC_TYPE_MASK | TrapzEvent.TRAPZ_BUFF_COMPLETE_MASK | ((self.category << 4) & TrapzEvent.TRAPZ_BUFF_CAT_ID_MASK)
        extra1 = self.e1
        extra2 = self.e2
        compTraceId1 = ((self.compId & 0xff0) >> 4)
        compTraceId2 = ((self.compId & 0xf) << 4) | ((self.traceId & 0xf00) >> 8)
        compTraceId3 = self.traceId & 0xff
        sec = int(self.timestamp / 1000000000)
        nsec = self.timestamp % 1000000000
        if self.e3 != 0 or self.e4 != 0 or self.e1 > 0xff or self.e2 > 0xff:
            ctrl = ctrl | 1
            extra1 = 0
            extra2 = 0
            ctrl2 = TrapzEvent.TRAPZ_BUFF_COMPLETE_MASK | ((self.category & TrapzEvent.TRAPZ_BUFF_CAT_ID_MASK) << 4)
            rec2 = struct.pack(TrapzEvent.STRUCT_EXTRA_FORMAT, ctrl2, self.sequence, 1, 0, self.e1, self.e2, self.e3, self.e4)
        rec1 = struct.pack(TrapzEvent.STRUCT_MAIN_FORMAT, ctrl, self.sequence, extra1, extra2, self.cpu, compTraceId1, compTraceId2, compTraceId3, self.pid, self.tid, sec, nsec)

        if rec2 is not None:
            rec1 += rec2

        return rec1

    def PrettyCsv(self, xml, offset=0):
        """Print as CSV with names. Needs XML parse tree. """
        try:
            component = xml.LookupComponent(self)
        except KeyError:
            # ad-hoc tracing might have components not in XML
            # just use component id
            componentStr = str(self.compId)
        else:
            componentStr = component.get('name')
        try:
            trace = xml.LookupTrace(self)
        except KeyError:
            # again, ad-hoc tracing
            traceStr = self.CombinedTraceName()
            formatString = None
        else:
            traceStr = trace.get('name')
            formatString = trace.get('formatString')

        parts = [str(self.timestamp+offset), str(self.sequence), str(self.cpu),
                 str(self.pid), str(self.tid),
                 TrapzEvent.CAT_TO_NAME[self.category], componentStr, traceStr,
                 str(self.e1), str(self.e2), str(self.e3), str(self.e4)]

        # append formatted string to end of line
        if formatString:
            try:
                parts.append(formatString % (self.e1, self.e2, self.e3, self.e4))
            except TypeError:
                try:
                    parts.append(formatString % (self.e1))
                except TypeError:
                    parts.append(formatString)

        return ', '.join(parts)

def ReadTrapzEventFromFile(binFile):
    eventData = binFile.read(TrapzEvent.STRUCT_SIZE)

    if len(eventData) != TrapzEvent.STRUCT_SIZE:
        # Zero read is normal for EOF
        if len(eventData) > 0:
            sys.stderr.write("ERROR: Partial record of size %d in %s, terminating\n" % (len(eventData), binFile.name))
        return None

    event = TrapzEvent(eventData, None)
    if (event.recType == 0):
        sys.stderr.write("ERROR: Encountered non-main record #%d, terminating.\n" % (event.sequence))
        return None

    if (event.extraRecCount > 0):
        eventExtraData = binFile.read(TrapzEvent.STRUCT_SIZE * event.extraRecCount)
        if len(eventExtraData) != TrapzEvent.STRUCT_SIZE:
            if len(eventExtraData) > 0:
                sys.stderr.write("ERROR: Partial extra record for %d of size %d in %s, terminating\n" % (event.sequence, len(eventExtraData), binFile.name))
            else:
                sys.stderr.write("ERROR: Missing extra record for %d in %s, terminating\n" % (event.sequence, binFile.name))
            return None
        event = TrapzEvent(eventData, eventExtraData)

    return event

def TrapzEventGenerator(binFile):
    """Generate TrapzEvents from a source. Currently only supports binary files.
    Avoids reading entire file into memory (could be larger than memory)"""

    counter = -1    
    firstEvent = None
    lastEvent = None
    totalLostData = 0

    binFile.seek(0)
    while 1:
        while 1:
            event = ReadTrapzEventFromFile(binFile)
            if ((event is None) or (lastEvent is None) or (event.sequence == 0)):
                #Break on EOF or scheduler data
                break

#            sys.stderr.write('INFO: Record %d(%d)\n' %
#                (event.timestamp, event.sequence))

            # The binary data contains overlapping records.  Skip 'em!
            if ((lastEvent.timestamp > event.timestamp) or
                    ((lastEvent.timestamp == event.timestamp) and (lastEvent.sequence >= event.sequence) and not
                    ((lastEvent.sequence == 255) and (event.sequence == 1)))):
#                sys.stderr.write('INFO: skipping overlapping record %d(%d), previous was %d(%d)\n' %
#                    (event.timestamp, event.sequence, lastEvent.timestamp, lastEvent.sequence))
                continue
            break

        # Stop on EOF or error
        if (event is None):
            if (totalLostData > 0):
                totalCaptureTime = lastEvent.timestamp - firstEvent.timestamp
                percDataLoss = round((((totalLostData * 1.0) / totalCaptureTime) * 100), 1)
                if (percDataLoss > 15):
                    sys.stderr.write('WARNING: ~%0.1f%% data loss.  Consider re-running with a smaller sleep time, a smaller number of enabled components, or increasing the trapz buffer size.\n' % (percDataLoss))
                elif (percDataLoss > 5):
                    sys.stderr.write('INFO: ~%0.1f%% data loss.\n' % (percDataLoss))
            break

        if (firstEvent is None):
            firstEvent = event

        if (event.sequence > 0):
            if (counter < 0):
                counter = event.sequence
            else:
                counter += 1
                if (counter > 255):
                    counter = 1
                if (counter != event.sequence):
                    # There seems to be a bug in the trapz driver that causes an occassional record with a 'bad' timestamp
                    # We just ignore this one record in this case.  Anything more than that implies discontinuity.
                    sequenceDiff = event.sequence - counter
                    if ((sequenceDiff != 1) and (sequenceDiff != -254)):
                        timeDiff = event.timestamp - lastEvent.timestamp
                        timeStartDiff = lastEvent.timestamp - firstEvent.timestamp
                        if (timeDiff != 0):
                            totalLostData += timeDiff
                            secDiff = int(timeDiff / 1000000000)
                            nsecDiff = timeDiff % 1000000000
                            secStartDiff = int(timeStartDiff / 1000000000)
                            nsecStartDiff = timeStartDiff % 1000000000
                            sys.stderr.write('INFO: Sequence discontinuity detected.  Missing %d.%ds of data at %d.%ds from start.\n' % (secDiff, nsecDiff, secStartDiff, nsecStartDiff))
                        else:
                            sys.stderr.write('INFO: Sequence discontinuity detected, but no unaccounted for time.\n')
                        #sys.stderr.write('INFO: Sequence discontinuity details: current: %d[%d], previous: %d[%d], expected sequence: %d\n' %
                        #    (event.timestamp, event.sequence, lastEvent.timestamp, lastEvent.sequence, counter))
                    counter = event.sequence
        lastEvent = event

        yield event

class TrapzEventList(list):
    """This class provides a handy list interface to Trapz file

    Example:
        t = Trapz('foo.txt') # or t = Trapz(openFileObject)
        t[33].pid = 666
        print t[44].timestamp
        """

    class ParseError(Exception):
        pass

    def __init__(self, arg=[]):
        list.__init__(self)
        try:
            # assume we're given a filename, open it
            trapzFile = open(arg, 'r')
        except TypeError:
            trapzFile = arg

        try:
            # assume we're given a file-like object, read it into a string
            trapzData = trapzFile.read()
        except AttributeError:
            trapzData = arg
        else:
            trapzFile.close()

        try:
            # assume we have a string, parse it
            trapzLines = trapzData.split('\n')
        except AttributeError:
            events = arg
            maxInvalid = 0
        else:
            if '\000' in trapzData:
                # This is binary trapz
                # Split into chunks based on trapz_entry_t length
                recordLen = TrapzEvent.STRUCT_SIZE
                events = [trapzData[i:i+recordLen] for i in xrange(0, len(trapzData), recordLen)]
                maxInvalid = 1
            else:
                # Continue parsing till we have a list of things ready to pass
                # to TrapzEvent constructor.
                events = [[x.strip() for x in l.split(',')] for l in trapzLines]
                # allow 2 invalid lines (1 for header, 1 for trailing empty line)
                maxInvalid = 2

        nInvalid = 0
        for event in events:
            try:
                self.append(event)
            except TypeError:
                nInvalid = nInvalid + 1
                if nInvalid > maxInvalid:
                    raise ParseError


    def append(self, event):
        if isinstance(event, TrapzEvent):
            list.append(self, event)
        else:
            # first convert to TrapzEvent
            list.append(self, TrapzEvent(event))

class VcdWriter:
    """Class to write VCD file.

    Calling order:
       ( SetTimeOffset | SetTimescale | Event ) *
       ( PushScope | WriteVar | PopScope ) *
       Finish
       """

    BINARY_VALUES = set(['0','1','x','z','X','Z'])

    @staticmethod
    def Verilogify(identifier):
        """convert a string to a valid Verilog identifier suitable for use in VCD file"""
        VERILOG_ID_ALLOWED = string.ascii_lowercase + string.ascii_uppercase + string.digits + "_$"
        vLogID = ''.join(c for c in identifier if c in VERILOG_ID_ALLOWED)
        return vLogID

    class VcdError(Exception):
        pass

    def __init__(self, vcdFile, compress=False):
        """compress: generate identifier codes on the fly which are far
        more space efficient than using the trace's full symbol name,
        but less readable if you ever want to look at the actual VCD
        file."""

        self.vcdFile = vcdFile
        if compress:
            raise NotImplementedError

        # enforce consistency in API
        self.headerWritten = False
        self.scopeDepth = 0

        # events is a list of (time, name, value) tuples
        self.vcdEvents = []
        # For each variable named foo, self.varRange[foo] contains the set of
        # values foo might take.
        self.varRange = {}
        # self.varRange is used to infer variable type
        self.varType = {}
        # for a variable named foo, self._lastTime[foo] is the timestamp of the last
        # foo event.
        self._lastTime = {}
        # you guessed it
        self._lastValue = {}
        # for each category bar, self.categories[bar] is a set of variables for that category
        self.categories = {}

        self.SetTimescale('s')
        self.SetTimeOffset(0)

    def SetTimeOffset(self, offset):
        assert not self.headerWritten
        self.offset = offset

    def SetTimescale(self, timescale):
        assert not self.headerWritten
        self.timescale = timescale
        if timescale == 's':
            self.timescaleFactor = 1000000000
        elif timescale == 'ms':
            self.timescaleFactor = 1000000
        elif timescale == 'us':
            self.timescaleFactor = 1000
        elif timescale == 'ns':
            self.timescaleFactor = 1
        else:
            raise AssertionError

    def _NextTime(self, time, name):
        '''Convert a monotonic time sequence to a strictly increasing one'''
        # this works because 'None >= x' returns False for any X
        lastT = self._lastTime.get(name, None)
        if lastT != None and lastT >= time:
         # jdm: this occurs a lot while tracing file I/O.  turning of.
            #timeShifts = (self._lastTime[name] - time)
            #if timeShifts > 5:
            #    # This should only happen if we have more than 10 simultaneous
            #    # events on the same trace. We could handle it, but that's
            #    # a really bad sign and we should complain.
            #    # raise VcdWriter.VcdError
            #    sys.stderr.write("WARNING: %s simultaneous events for %s at %s\n" % \
            #                         (timeShifts, name, time))
            self._lastTime[name] += 1
            return self._lastTime[name]
        else:
            self._lastTime[name] = time
            return time

    def Event(self, time, name, value):
        '''Adds an event to VCD file

        Caller must ensure that events for a given name are monotonic in time
        (i.e. successive events must have equal or greater timestamps).
        VcdWriter handles the following aspects of VCD syntax:
        1) Determining signal type
        2) Modifiying timestamps to enforce strictly increasing event times
        3) Inserting glitches when successive events have the same value'''

        assert not self.headerWritten

        if (self._lastValue.get(name, None) == value):
            # Send 'X' for glitch, unless it's already 'X' in
            # which case send 'Z'
            if value.upper() == 'X':
                self.vcdEvents.append((self._NextTime(time, name), name, 'Z'))
            else:
                self.vcdEvents.append((self._NextTime(time, name), name, 'X'))
        self.vcdEvents.append((self._NextTime(time, name), name, value))
        self._lastValue[name] = value

        # add "value" to range of "name"
        self.varRange.setdefault(name, set()).add(value)

    def PushScope(self, name):
        if not self.headerWritten:
            self._WriteHeader()
            self.headerWritten = True
        self._WriteSection("scope", "module %s" % name)
        self.scopeDepth = self.scopeDepth + 1

    def WriteVar(self, symbol, name):
        """Writes a variable declaration to VCD file in current scope.
        symbol: must be a globally unique string identifying this trace
        name: a short, descriptive name that does not need to be unique"""

        if symbol not in self.varRange:
            # This means that caller is trying to add a trace which hasn't had
            # any events. In general it shouldn't happen, caller shouldn't add
            # variables that don't exist. However there are corner cases
            # (e.g. a delta signal will be added for a trace which occurs
            # exactly once in the log, but without two occurances there is no
            # delta).
            return

        # XXXmunsal can dramatically reduce size of output VCD file by hashing
        # symbol into something short & unique instead of long & unique
        if not self.headerWritten:
            self._WriteHeader()
            self.headerWritten = True
        valueSet = self.varRange[symbol]
        if valueSet.issubset(self.BINARY_VALUES):
            # this is a one bit binary trace
            self._WriteSection("var", "reg 1 @%s %s" % (symbol, name))
        else:
            self._WriteSection("var", "real 1 @%s %s" % (symbol, name))

    def PopScope(self):
        assert self.headerWritten
        self._WriteSection("upscope", "")
        self.scopeDepth = self.scopeDepth - 1

    def Finish(self, showProgress=False):
        assert self.headerWritten
        assert self.scopeDepth == 0
        self._WriteSection("enddefinition", "")
        curTime = None
        self.vcdEvents.sort()
        firstEvtTup = self.vcdEvents[0]
        self.offset = -firstEvtTup[0]

        if showProgress:
            print "Writing VCD events"
            nEvents = len(self.vcdEvents)
            iEvent = 0
            if nEvents <= 10000:
                # don't bother with percent progress
                showProgress = False

        for (time, name, value) in self.vcdEvents:

            if showProgress:
                if iEvent % (nEvents / 20) == 0:
                    print "%d%%.." % (iEvent * 100 / nEvents),
                    sys.stdout.flush()
                iEvent+=1

            time = time + self.offset
            # so far our timestamps are integer numbers of nanoseconds
            # now convert to floating point for VCD purposes
            time = float(time) / self.timescaleFactor

            if time != curTime:
                curTime = time
                # str(curTime) uses scientific notation in some cases.. this
                # forces engineering notation.
                self.vcdFile.write("#%f\n" % curTime)

            if self.varType[name] is bool:
                self.vcdFile.write("%s@%s\n" % (value, name))
            elif self.varType[name] is str:
                # XXXmunsal this is a special feature of GTKWave which is not
                # compliant with VCD specification
                try:
                    self.vcdFile.write("s%s @%s\n" % (value, name))
                except UnicodeEncodeError:
                    # some crazy people in Apps are putting unicode in tracepoint names
                    # (e.g. book titles with Japanese characters)
                    # VCD definitely won't understand that so ignore nonprintable characters
                    self.vcdFile.write("s%s @%s\n" % (value.encode('ascii', errors='ignore'), name))
            elif self.varType[name] is float:
                # VCD doesn't support X or Z in real valued variable
                if value.upper() == 'X':
                    value = -1
                elif value.upper() == 'Z':
                    value = -2
                self.vcdFile.write("r%s @%s\n" % (value, name))
            else:
                raise AssertionError
        self.vcdFile.close()
        self.vcdFile = None
        if showProgress:
            print

    def _WriteSection(self, keyword, contents, delimiter=" "):
        self.vcdFile.write(delimiter.join(("$"+keyword,
                                           contents,
                                           "$end\n")))

    def _WriteHeader(self):
        assert not self.headerWritten

        # infer type of signals from range
        # we do this here because we know we're not getting any more events
        for (name, values) in self.varRange.items():
            if values.issubset(self.BINARY_VALUES):
                self.varType[name] = bool
            elif all(map(operator.methodcaller("isdigit"), values)):
                # note operator.methodcaller() required to support both string and unicode
                self.varType[name] = float
            else:
                self.varType[name] = str

        self._WriteSection("date", str(datetime.now()))
        self._WriteSection("version", "%s %s" % (os.path.basename(sys.argv[0]), VERSION))
        self._WriteSection("timescale", "1 %s" % self.timescale)
        self.headerWritten = True




class TrapzXmlParser:
    """This class represents an XML parse tree and has a function
    Traverse to facilitate tree traversal. This is mostly used as a
    base class. Despite the name, it doesn't actually know anything in
    particular about TRAPZ."""

    def __init__(self):
        # Just to make my life simple, let's enforce that Parse can only
        # be called once.
        self.parsed = False
        pass

    # def __del__(self):
    #     # XXXmunsal just for debugging purposes, emit the full parse
    #     # tree as XML before we exit
    #     self.tree.write('.debug-%s.xml' % self.__class__.__name__)

    def Parse(self, xmlFile):
        """Loads XML file into parse tree"""
        assert not self.parsed
        self.tree = ElementTree.parse(xmlFile)

        # This is the top document node, which should be <trapz>
        # 1) It always contains a component tree, which may be decorated with
        # trace nodes as well.
        # 2) It may contain an embedded XSLT stylesheet
        # 3) It may contain a sequence event nodes
        #
        # Normally trapz.xml had 1 (no trace nodes), trapz-generated.xml has
        # 1 and 2 (with trace nodes), and output of `trapz -x` contains all 3.
        self.root = self.tree.getroot()
        assert self.root.tag == 'trapz'
        version = self.root.get('version')
        if version:
            if version != VERSION:
                sys.stderr.write('WARNING: Version mismatch. Trapztool is %s, XML is %s\n' % (VERSION, version))
                sys.stderr.write('WARNING: A full build and reflash should resolve this problem.\n')
                sys.stderr.write('WARNING: In the meantime you may get unexpected results.\n')
        else:
            # XML in tree is unversioned. Add version to our generated XML
            self.root.set('version', VERSION)


        self.rootComponent = self.root.find('component') # this is the root of the component tree
        self.stylesheet = None   # this is a string (not an Element tree) with the embedded stylesheet
        self.parsed = True

    def AddEmbeddedStylesheet(self, xslFile):
        try:
            f = open(xslFile, 'r')
        except IOError:
            f = xslFile
        self.stylesheet = f.read()
        f.close()
        # Add id to stylesheet so that processing instuction can find it with
        # an anchor href. Also discard anything preceeding <xsl:stylesheet> element.
        (pre, ss, post) = self.stylesheet.partition('<xsl:stylesheet')
        self.stylesheet = ''.join((ss, ' id="stylesheet"', post))

    def PrettyXml(self):
        # ElementTree seems not to be very good at writing pretty XML.
        # So unfortunately this is a bit circuitous
        uglyXml = ElementTree.tostring(self.root).replace('\n','')
        from xml.dom import minidom
        dom = minidom.parseString(uglyXml)
        if self.stylesheet:
            # Need to add DOCTYPE so that browser does not barf on id attribute
            # in embedded xsl:stylesheet node. See:
            #   http://stackoverflow.com/questions/360628/embed-xsl-into-an-xml-file
            docType = minidom.getDOMImplementation().createDocumentType('trapz', None, None)
            docType.internalSubset = '<!ATTLIST xsl:stylesheet id ID #REQUIRED>'
            dom.insertBefore(docType, dom.documentElement)
        # ElementTree discards the processing instruction so we need to add it back in.
        # Points either to trapz.xsl (assumed to be in current directory) or embedded
        # stylesheet (if present).
        pi = dom.createProcessingInstruction('xml-stylesheet',
                                             'type="text/xsl" href="%s"' % \
                                                 ("#stylesheet" if self.stylesheet else "trapz.xsl"))
        dom.insertBefore(pi, dom.documentElement)
        almostPrettyXml = dom.toprettyxml(indent="  ")
        # remove empty lines
        prettyXml = '\n'.join([line for line in almostPrettyXml.split('\n') if line and not line.isspace()]) + '\n'
        # add stylesheet at end of document
        if self.stylesheet:
            prettyXml = prettyXml.replace('</trapz>', self.stylesheet + '</trapz>')
        return prettyXml

    def Write(self, xmlFile):
        self.tree.write(xmlFile)

    def WritePrettyXml(self, xmlFile):
        f = open(xmlFile, 'w')
        f.write(self.PrettyXml())
        f.close()

    def Traverse(self, root, preProcess=None, postProcess=None, tagFilter=None):
        """Traverses XML tree, invoking helper functions for each node

        preProcess is called before traversing the subtree, with a
        single argument 'path', a list of elements starting with the
        root and ending with the current element.

        postProcess is similar, called after traversing the subtree

        tagFilter restricts the traversal to a particular element tag"""
        self._TraverseHelper([root], preProcess, postProcess, tagFilter)

    def _TraverseHelper(self, path, preProcess, postProcess, tagFilter):
        """Recursive helper to traverse parse tree"""

        element = path[-1]
        if XSL_NAMESPACE in element.tag:
            # never traverse into stylesheet nodes
            return

        if preProcess:
            preProcess(path)

        # here's the depth first traversal
        if tagFilter:
            children = element.findall(tagFilter)
        else:
            children = list(element)

        for child in children:
            self._TraverseHelper(path + [child], preProcess, postProcess, tagFilter)

        if postProcess:
            postProcess(path)


class TrapzXmlValidator(TrapzXmlParser):
    """Extends TrapzXmlParser to ensure that the parse tree is Trapz compliant
    and fully populated with component and trace IDs. Also maintains
    dictionaries to look up components by ID. Also provides methods to add new
    components/traces while maintaining validity. Also converts event elements
    into a list using Trapz class."""

    @staticmethod
    def FullSymbol(path):
        """Returns the full symbol of a tree node given the traversal path to it
        e.g. TRAPZ_KERNEL_DISPLAY_DSS"""
        return '_'.join([e.get('symbol') for e in path if e.tag != 'trapz'])

    def __init__(self):
        TrapzXmlParser.__init__(self)
        # create an empty event list
        self.events = TrapzEventList()
        self.binFiles = []

    def Parse(self, xmlFile):
        # call super
        TrapzXmlParser.Parse(self, xmlFile)
        # and validate
        self.Validate()

    def ParseMultiple(self, logFiles):
        """ Not actually used """
        gotXml = False
        events = []

        for logFile in logFiles:
            # if we haven't parsed an XML file yet, try parsing as XML
            if not gotXml:
                try:
                    self.Parse(logFile)
                except ElementTree.XmlParseError:
                    # next we're going to try parsing this into a TrapzEventList
                    pass
                else:
                    gotXml = True
                    continue

            # assuming all others are CSV or binary
            try:
                events.extend(TrapzEventList(logFile))
            except TrapzEventList.ParseError:
                # it ain't CSV either ... we're out of luck
                sys.stderr.write("ERROR: can't parse file as XML, CSV, or binary\n")
                sys.exit(1)

        if not gotXml:
            sys.stderr.write("ERROR: one of the input files must be XML\n")
            sys.exit(1)

    def ParseXmlOrCsv(self, logFile, xmlFile=None):
        """Try parsing the logfile as XML. If that doesn't work, try parsing
        as CSV or binary file using seperate XML."""

        try:
            # assuming XML
            self.Parse(logFile)
        except ElementTree.XmlParseError:
            # well it ain't XML
            try:
                # assuming CSV or binary
                events = TrapzEventList(logFile)
            except TrapzEventList.ParseError:
                # it ain't CSV either ... we're out of luck
                raise AssertionError

            # we need to get XML structure from somewhere
            if xmlFile.endswith('.xml') and not xmlFile.endswith('-generated.xml') \
                    and os.path.exists(xmlFile.replace('.xml', '-generated.xml')):
                xmlFile = xmlFile.replace('.xml', '-generated.xml')
            self.Parse(xmlFile)

            # Our event list should be empty after parsing the generated XML,
            # which has no events. Replace it with the one we read from CSV.
            assert len(self.events) == 0
            self.events = events

        # verify sequence numbers
        for i in xrange(len(self.events) - 1):
            if (self.events[i+1].sequence - self.events[i].sequence) != 1:
                sys.stderr.write('WARNING: sequence discontinuity from %d to %d\n' % \
                                     (self.events[i].sequence, self.events[i+1].sequence))

    def Validate(self):
        self._componentsById = {}
        self._tracesById = {}
        # map component's full symbols to component element
        self.componentsByFullSymbol = {}
        self.Traverse(self.root, preProcess=self._ValidateElement)

    def LookupComponent(self, event):
        """Lookup component by category and componentId"""
        return self._componentsById[event.ComponentSignature()]

    def _select_by_attr(self, element_list, attr_name, attr_val ):
        def selection_closure(path):
            elt = path[-1]
            if elt.get(attr_name) == attr_val:
                element_list.append( elt )
        return selection_closure

    def FilterComponentsByAttr( self, root_element, attr_name, attr_val ):
        result_list = []
        self.Traverse( root_element, tagFilter="component",
                preProcess=self._select_by_attr( result_list, attr_name, attr_val ) )
        return result_list


    def AddComponentForEvent(self, path, event):
        """Add a component. Path must be the FULL path of parent
        nodes."""
        component = ElementTree.Element('component')
        component.set('cat', str(event.category))
        component.set('id', str(event.compId))
        # a semi-bogus name and symbol is the best we can do
        component.set('name', str(event.compId))
        component.set('symbol', str(event.compId))
        path[-1].append(component)
        self._ValidateComponent(path + [component])
        return component

    def LookupTrace(self, event):
        return self._tracesById[event.TraceSignature()]

    def AddTraceForEvent(self, parent, event):
        """Add a trace for an event. Parent is an XML node."""
        trace = ElementTree.Element('trace')
        trace.set('cat', str(event.category))
        trace.set('id', str(event.traceId))
        trace.set('name', parent.get('name') + '_' + event.CombinedTraceName())
        parent.append(trace)
        # Fortunately _ValidateTrace only requires the immediate
        # parent node to be in the path. Enforce this by setting
        # grandparent to None, which will raise an assertion if
        # _ValidateTrace ever decides it needs the full path.
        self._ValidateTrace([None, parent, trace])
        return trace

    def AddEvent(self, event):
        """Add an event to our event list. Normally called with an
        Element object by _ValidateElement."""
        self.events.append(event)

    def AddBinFile(self, binFile):
        self.binFiles.append(binFile)

    def _GenerateEvents(self):
        """Generate all events (combining XML and BIN files if applicable)"""
        # itertools.chain would be a fancy way to do this but I think this is more readable
        for event in self.events:
            yield event
        for binFile in self.binFiles:
            for event in TrapzEventGenerator(binFile):
                yield event

    def _GenerateSequenceWarning(self, events):
        prevEvent = next(events)
        yield prevEvent
        for event in events:
            # ignore sequence numbers <0
            if event.sequence - prevEvent.sequence != 1 and prevEvent.sequence >= 0 and event.sequence >= 0:
                sys.stderr.write('WARNING: sequence discontinuity from %d to %d\n' % \
                                     (prevEvent.sequence, event.sequence))
            yield event
            prevEvent = event

    def _GenerateProgress(self, events):
        firstEvent = next(events)
        yield firstEvent
        # negative timestamps are invalid, skip
        while firstEvent.timestamp < 0:
            firstEvent = next(events)
            yield firstEvent
        currentMinute = 0
        while 1:
            try:
                nextEvent = next(events)
            except StopIteration:
                if currentMinute:
                    print
                raise StopIteration
            else:
                minute = int((nextEvent.timestamp - firstEvent.timestamp) / 1000000000 / 60)
                if minute > currentMinute:
                    print "%dm.. " % minute,
                    sys.stdout.flush()
                    currentMinute = minute
                yield nextEvent

    def GenerateEvents(self, showProgress=False, sequenceWarning=False):
        generator = self._GenerateEvents()
        if showProgress:
            generator = self._GenerateProgress(generator)
        if sequenceWarning:
            generator = self._GenerateSequenceWarning(generator)
        return generator

    def _ValidateElement(self, path):
        element = path[-1]
        # call helper functions for each node type
        if element.tag == 'component':
            self._ValidateComponent(path)
        elif element.tag == 'trace':
            self._ValidateTrace(path)
        elif element.tag == 'event':
            self.AddEvent(element)
        elif element.tag in set(['trapz', 'scan', 'description']):
            pass
        else:
            raise AssertionError

    def _ValidateComponent(self, path):
        element = path[-1]
        assert 'name' in element.keys()
        assert 'symbol' in element.keys()
        assert 'id' in element.keys()
        assert 'cat' in element.keys()

        # ensure that component signature (cat, compId) is unique
        cat = int(element.get('cat'))
        compId = int(element.get('id'))
        idSignature = (cat, compId)
        if idSignature in self._componentsById:
            # this was just a cryptic assertion but it happens enough to require some
            # explanation
            sys.stderr.write('ERROR: XML contains more than one component with ID %d ' \
                                 'for category %d\n' % \
                                 (compId, cat))
            sys.stderr.write('Existing component name "%s" symbol "%s"\n' % \
                                 (self._componentsById[idSignature].get('name'),
                                  self._componentsById[idSignature].get('symbol')))
            sys.stderr.write('Conflicting component name "%s" symbol "%s"\n' % \
                                 (element.get('name'),
                                  element.get('symbol')))
            return
        self._componentsById[idSignature] = element

        # generate map of symbols to component objects
        fullSymbol = self.FullSymbol(path)
        assert fullSymbol not in self.componentsByFullSymbol
        self.componentsByFullSymbol[fullSymbol] = element
        element.set('fullSymbol', fullSymbol)

    def _ValidateTrace(self, path):
        element = path[-1]
        component = path[-2]
        assert 'name' in element.keys()
        # assert 'symbol' in element.keys()
        assert 'id' in element.keys()

        # ensure that trace signature (category, compId, traceId) is unique
        cat = int(component.get('cat'))
        compId = int(component.get('id'))
        traceId = int(element.get('id'))
        idSignature = (cat, compId, traceId)
        if idSignature in self._tracesById:
            # this was just a cryptic assertion but it happens enough to require some
            # explanation
            sys.stderr.write('ERROR: XML contains more than one trace with ID %d ' \
                                 'for category %d component %d\n' % \
                                 (traceId, cat, compId))
            sys.stderr.write('Existing trace name "%s"\n' % \
                                 self._tracesById[idSignature].get('name'))
            sys.stderr.write('Conflicting trace name "%s"\n' % element.get('name'))
            return
        self._tracesById[idSignature] = element

        # VCD requires a unique ID string for each signal. We
        # construct one from the full symbol of the parent
        # component (which is guaranteed to be globally unique)
        # and the name of this trace (which is guaranteed to be
        # unique within the component).

        vcdId = component.get('fullSymbol') + '_' + element.get('name')
        element.set('vcdId', vcdId)



class SimpleTrapz(TrapzXmlValidator):
    """Extends TrapzXmlValidator to offer convenience methods
    for accessing and working with the contents of a trapz XML file.

    Pass XML file pathname when constructing.

    """

    def __init__(self, xmlfile):
        TrapzXmlValidator.__init__(self)

        self.Parse(xmlfile)

    # replace with general version below
    def _select_by_name_attr(self, element_list, name_val ):
        def selection_closure(path):
            elt = path[-1]
            if elt.get("name") == name_val:
                element_list.append( elt )
        return selection_closure


    def findComponentByName(self, component_name):
        """Return DOM element for named component"""

        # xpath not available in early version
        #components = self.rootComponent.findall(".//component[@name='%s']" % component_name)

        components = []

        self.Traverse( self.rootComponent, tagFilter="component",
                            preProcess=self._select_by_name_attr( components, component_name ) )

        if len(components) == 0:
            return None
        if len(components) > 1:
            sys.stderr.write("WARNING: multiple component found with name or symbol %s\n" % component_name)
            for component in components:
                sys.stderr.write("catId %s compId %s\n" % (component.get('cat'), component.get('id')))
        return components[0]

    def findTraceByName(self, component, trace_name):
        """Return DOM element for named trace within specified component element"""
        # xpath not available in early version
        #traces = component.findall(".//trace[@name='%s']" % trace_name)

        traces = []
        self.Traverse( component, tagFilter="trace",
                            preProcess=self._select_by_name_attr( traces, trace_name ) )

        if len(traces) == 0:
            return None

        return traces[0]

    def getIds(self, component_name=None, trace_name=None):
        """Return a tuple with category_id, component id, and trace_id corresponding
        to the component and trace names provided"""

        if component_name is None:
            return ()

        component = self.findComponentByName(component_name)
        if component is None:
            return ()

        if trace_name is None:
            return int(component.get("cat")), int(component.get("id"))

        trace = self.findTraceByName(component, trace_name)
        if trace is None:
            return ()

        id_tuple = int(component.get("cat")), int(component.get("id")), int(trace.get("id"))
        return id_tuple

    def eventMatch(self, event, ids):
        """Match a trace event (cat,comp,trace) against a tuple of id's"""
        if len(ids) >= 3:
            return event.category == ids[0] and event.compId == ids[1] and event.traceId == ids[2]
        elif len(ids) == 2:
            return event.category == ids[0] and event.compId == ids[1]
        elif len(ids) == 1:
            return event.category == ids[0]
        else:
            return False

    def filterEvents(self, component_name=None, trace_name=None, events=None):
        """Return a filtered set of trace events.
        # XXXmunsal make this a generator

        trace_name is optional
        if 'events' not passed, will use entire list of events

        """

        if events is None:
            events = self.GenerateEvents()

        # will only get cat/comp back if trace_name is None
        ids = self.getIds( component_name, trace_name )
        return [event for event in events if self.eventMatch(event, ids)]

    def findNextEvent(self, mark_event, component_name, trace_name, events=None):
        """Return first element which follows specified 'mark_event' that matches (optional) component and trace names.

        Can pass optional 'events' argument to search in filtered list, otherwise will search in all events

        """
        if events is None:
            events = self.GenerateEvents()

        ids = self.getIds(component_name,trace_name)

        # we'll seek for the mark_event if provided
        if mark_event is None:
            seeking = False
        else:
            seeking = True

        result = None

        for ev in events:
            if seeking:
                seeking = (ev.sequence != mark_event.sequence)
            else:
                if self.eventMatch(ev, ids):
                    result = ev
                    break

        return result


class PowerBucket:
    """Records and analyzes time spent in different CPU OPPs for some activity
    such as a thread or a scope within a thread"""

    # describes how we print ourselves out
    FIELDS = [
        {'name': 'Avg mA',
         'width': 8,
         'format': '%*.4f',
         'value': lambda bucket, totalTime: bucket.GetEnergy() / totalTime / 3.7 * 1000.},
        {'name': 'Avg MIPS',
         'width': 8,
         'format': '%*.4f',
         'value': lambda bucket, totalTime: bucket.GetMIPS() / totalTime},
        {'name': 'Load%',
         'width': 5,
         'format': '%*.2f',
         'value': lambda bucket, totalTime: bucket.GetElapsed() / totalTime * 100.},
        {'name': 'Sched/s',
         'width': 7,
         'format': '%*.2f',
         'value': lambda bucket, totalTime: bucket.GetSwitches() / totalTime},
        {'name': 'Name',
         'width': 16,
         'format': '%*s',
         'value': lambda bucket, totalTime: bucket.name if bucket.name else ""}
        ]

    @classmethod
    def HeaderString(cls, csv=False):
        delimiter = ', ' if csv else ' '
        headings = delimiter.join(['%*s' % (field['width'], field['name']) for field in cls.FIELDS])
        if csv:
            return headings
        else:
            underlines = delimiter.join([field['width']*'=' for field in cls.FIELDS])
            return headings + '\n' + underlines

    def __init__(self, name):
        self.name = name
        # elapsed maps DVFS freq in khz to runtime in seconds
        self.elapsed = {}
        # this counts context switches
        self.switches = 0

    def ResultString(self, totalTime, csv=False):
        delimiter = ', ' if csv else ' '
        return delimiter.join([field['format'] % (field['width'], field['value'](self, totalTime))
                                   for field in self.FIELDS])

    def Timeslice(self, freq, seconds):
        try:
            self.elapsed[freq] += seconds
        except KeyError:
            self.elapsed[freq] = seconds

    def Switch(self, n=1):
        self.switches += n

    def GetElapsed(self):
        return sum(self.elapsed.values())

    def GetEnergy(self):
        """Returns the energy consumed by the thread in watt-seconds (joules)"""
        return sum([MPU_POWER_BY_OPP[freq] * elapsed for (freq, elapsed) in self.elapsed.items()])

    def GetMIPS(self):
        """Returns the cumulative "MIPS" consumed by the process. It's really the number of
        clock cycles in millions, it is MIPS only assuming 1 instruction / cycle."""
        return sum([freq / 1E6 * elapsed for (freq, elapsed) in self.elapsed.items()])

    def GetMIPSPerWatt(self):
        energy = self.GetEnergy()
        mips = self.GetMIPS()
        if energy == 0:
            assert mips == 0
            return 0
        else:
            return mips / energy

    def GetSwitches(self):
        return self.switches

class NestedPowerBucket(PowerBucket):

    def __init__(self, name):
        PowerBucket.__init__(self, name)
        # These are "sub-buckets" owned by us. Indexed by name.
        # Active ones inherit our time slices.
        self.subBuckets = {}
        self.activeSubBuckets = {}

    def CreateSubBucket(self, key, name):
        """Creates a subBucket."""
        self.subBuckets[key] = PowerBucket(name)

    def ActivateSubBucket(self, key):
        """Activates a subBucket. While it is active, it will also get
        blamed for our timeslices."""
        assert key not in self.activeSubBuckets
        self.activeSubBuckets[key] = self.subBuckets[key]

    def DeactivateSubBucket(self, key):
        """Deactivates a subBucket. It will no longer get
        blamed for our timeslices."""
        del self.activeSubBuckets[key]

    def Timeslice(self, freq, seconds):
        PowerBucket.Timeslice(self, freq, seconds)
        # recurse into subbuckets
        for bucket in self.activeSubBuckets.values():
            bucket.Timeslice(freq, seconds)

    def Switch(self, n=1):
        PowerBucket.Switch(self, n)
        # recurse into subbuckets
        for bucket in self.activeSubBuckets.values():
            bucket.Switch(n)

    def ResultString(self, totalTime, csv=False):
        results = [PowerBucket.ResultString(self, totalTime, csv)]
        for scope in self.subBuckets.values():
            results.append(scope.ResultString(totalTime, csv))
        return '\n'.join(results)

class PowerThread(NestedPowerBucket):
    """This is the power bucket for a thread"""

    FIELDS = PowerBucket.FIELDS + [
        {'name': 'PidName',
         'width': 16,
         'format': '%*s',
         'value': lambda thread, totalTime: thread.parent.name if thread.parent else ""},
        {'name': 'Tid',
         'width': 5,
         'format': '%*s',
         'value': lambda thread, totalTime: str(thread.tid) if thread.tid is not None else ""},
        {'name': 'Pid',
         'width': 5,
         'format': '%*s',
         'value': lambda thread, totalTime: str(thread.pid) if thread.pid is not None else ""},
        {'name': 'MIPS/watt',
         'width': 9,
         'format': '%*.2f',
         'value': lambda thread, totalTime: thread.GetMIPSPerWatt()}
        ]

    def __init__(self, tid, pid=None, name=None, children=None):
        """pid and name are optional because we sometimes have to create a
        thread in response to a context switch event, where we only know the
        tid subThreads"""

        NestedPowerBucket.__init__(self, name)

        self.tid = tid
        self.pid = pid

        self.parent = None
        self.children = []

        # Are we in secure world?
        self.secureWorld = False

        if children:
            self.children = children
            for child in self.children:
                for (freq, time) in child.elapsed.items():
                    self.Timeslice(freq, time)
                self.Switch(child.switches)

    def SetPid(self, pid):
        if self.pid and (pid != self.pid):
            # should never happen
            sys.stderr.write('ERROR: reparenting thread %d from %d to %d\n' % \
                                 (self.tid, self.pid, pid))
            # sys.exit(1) # argh! this actually happens with PID wraps
        self.pid = pid

    def SetName(self, name):
        if self.name and (name != self.name):
            # threads probably shouldn't be renamed very often.... this is weird at the minimum
            sys.stderr.write('WARNING: renaming tid %d from %s to %s\n' % \
                                 (self.tid, self.name, name))
        self.name = name

    def SetParent(self, parent):
        self.parent = parent
        self.parent.children.append(self)

    def IsChild(self):
        return self.pid and self.pid != self.tid

    def GetProcess(self):
        """Returns a PowerThread object that represents the cumulative statistics for the
        whole process"""
        if self.IsChild():
            return self.parent.GetProcess()
        return self.__class__(self.tid, self.pid, self.name, children=self.children)


class PowerTrapz(SimpleTrapz):

    SECURE_TID_MASK = 65536  # comfortably larger than PID_MAX

    def __init__(self, xmlFile, fromSeq=0, toSeq=sys.maxsize, fromTime=0.0, toTime=10000.0, n=sys.maxsize,
                 emitSecureStats=False, emitCpufreqStats=False, emitPowerScopes=False):

        self.emitSecureStats = emitSecureStats
        self.emitCpufreqStats = emitCpufreqStats
        self.emitPowerScopes = emitPowerScopes

        if self.emitCpufreqStats:
            freqs = MPU_POWER_BY_OPP.keys()
            freqs.sort()
            for freq in freqs:
                # XXXmunsal this is kinda bogus to modify a class variable,
                # but it won't actually cause any problems with our current usage.
                PowerThread.FIELDS.append(
                    {'name': 'time@%4d' % (freq / 1000000),
                     'width': 9,
                     'format': '%*.2f',
                     'value': lambda thread, totalTime, freq=freq: thread.elapsed.get(freq, 0.)})

        # read XML file and parse out the events we are looking for
        SimpleTrapz.__init__(self, xmlFile)
        (self.kernCatId, self.schedCompId, self.ctxSwTraceId) = self.getIds("Scheduler", "CtxSw")
        (self.kernCatId, self.schedCompId, self.tc1TraceId) = self.getIds("Scheduler", "TaskComm")
        (self.kernCatId, self.schedCompId, self.exitTraceId) = self.getIds("Scheduler", "Exit")
        (self.kernCatId, self.dvfsCompId, self.dvfsTraceId) = self.getIds("DVFS", "DVFSChangeFreq")
        if self.emitSecureStats:
            (self.kernCatId, self.secCompId, self.secTraceId) = self.getIds("Security", "SecureDispatcher")

        # event bounds for analysis
        self.fromSeq = fromSeq
        self.toSeq = toSeq
        self.fromTime = fromTime * 1000000000.0
        self.toTime = toTime * 1000000000.0
        self.n = n
        self.i = 0
        self.basetime = -1
        self.threads = {}
        self.defunctThreads = []

        # add idle process
        self._NewThread(0, 0, "idle")

        # 1.2 GHz default frequency
        self.dvfsFreq = 1200000000
        # this isn't great
        self.cpus = (0,1)
        self.cpuCurrentTid = {}
        self.cpuLastTimestamp = {}
        for cpu in self.cpus:
            self.cpuCurrentTid[cpu] = 0 # idle

    def _NewThread(self, tid, pid=None, name=None):
        if tid in self.threads:
            # already exists
            if name:
                self.threads[tid].SetName(name)
            if pid:
                self.threads[tid].SetPid(pid)
        else:
            self.threads[tid] = PowerThread(tid, pid, name)


    def Results(self, threads, csv=False):

        totalTime = (self.cpuLastTimestamp[0] - self.startTime) / 1E9

        lines = []
        if csv:
            lines.append('%8.4f,total sec' % totalTime)
        else:
            lines.append('Total time: %8.4f seconds' % totalTime)
            lines.append('')

        lines.append(PowerThread.HeaderString(csv))

        for thread in threads:
            lines.append(thread.ResultString(totalTime, csv))

        return '\n'.join(lines)

    def _HandleDvfsEvent(self, event):
        # common code for DVFS and CtxSw events:
        self._HandlePowerEvent(event)
        # this is a DVFS (frequency change) event
        self.dvfsFreq = event.e1

    def _HandleCtxSwEvent(self, event):
        # common code for DVFS and CtxSw events:
        self._HandlePowerEvent(event)

        # is the thread in secure world?
        tid = (event.e2 << 8) | event.e1
        if tid in self.threads and self.threads[tid].secureWorld:
            tid |= self.SECURE_TID_MASK

        # increment ctxsw count for the tid we are switching to
        try:
            self.threads[tid].Switch()
        except KeyError:
            self._NewThread(tid)
            self.threads[tid].Switch()

        self.cpuCurrentTid[event.cpu] = tid


    def _HandleSecureEvent(self, event):

        # these sometimes happen from interrupt context. ignore them
        if event.tid == event.pid == 0:
            return

        # common code for DVFS and CtxSw events:
        self._HandlePowerEvent(event)

        if event.e2 == 1:
            # entering secure world
            threadId = self.cpuCurrentTid[event.cpu]
            secureId = threadId | self.SECURE_TID_MASK
            if threadId == secureId:
                # This is really bad. this probably means we missed the switch
                # from secure world earlier. (Perhaps at the beginning of the
                # trace.)
                sys.stderr.write('WARNING: unexpected entry to secure world for thread %d seq %d\n' % \
                                     (threadId, event.sequence))
                assert self.threads[threadId].secureWorld is True
            else:
                assert self.threads[threadId].secureWorld is False

            # Make sure we have a "secure thread" which is an imaginary child
            # thread which is used to account for time this process spends in
            # secure world.
            if secureId not in self.threads:
                threadName = self.threads[threadId].name
                if threadName is None:
                    threadName = ""
                self._NewThread(secureId, event.pid, threadName + ' SEC')
            # Switch to secure thread
            self.cpuCurrentTid[event.cpu] = secureId
            self.threads[threadId].secureWorld = True
            # Record this as a context switch for secureId. Even though we're
            # not actually going through the scheduler, I do want to at least
            # keep track of how often we are entering secure world.
            self.threads[secureId].Switch()
        elif event.e2 == 0:
            # Exiting secure world
            secureId = self.cpuCurrentTid[event.cpu]
            threadId = secureId & ~self.SECURE_TID_MASK
            if secureId == threadId:
                # This is really bad. this probably means we missed the switch
                # to secure world earlier. (Perhaps at the beginning of the
                # trace.)
                sys.stderr.write('WARNING: unexpected exit from secure world for thread %d seq %d\n' % \
                                     (threadId, event.sequence))
                assert self.threads[threadId].secureWorld is False
            else:
                assert self.threads[threadId].secureWorld is True
            # switch back to insecure thread
            self.cpuCurrentTid[event.cpu] = threadId
            self.threads[threadId].secureWorld = False
            # Don't record this as a context switch for current TID, because
            # it's not going through the scheduler. This is the one way in
            # which we treat the secure world transition differently from an
            # actual context switch in terms of our accounting statistics.
        else:
            raise AssertionError

    def _HandlePowerEvent(self, event):
        # Do power bookkeeping on any scheduler or DVFS event.  This brings our
        # bookkeeping up to date for the period between the last event and this
        # one.
        for cpu in self.cpus:
            try:
                elapsed = (event.timestamp - self.cpuLastTimestamp[cpu]) / 1E9
            except KeyError:
                # first time thru, cpuLastTimestamp doesn't exist
                elapsed = 0
                self.startTime = event.timestamp

            self.threads[self.cpuCurrentTid[cpu]].Timeslice(self.dvfsFreq, elapsed)

            # update cpu info for next time thru
            self.cpuLastTimestamp[cpu] = event.timestamp

    def _HandleTaskCommEvent(self, tcEvent):
        # XXXmunsal should handle case where task name is changed
        # rstrip nulls, because thread name from TRAPZ will be null terminated
        self._NewThread(tc1Event.tid, tc1Event.pid,
                        struct.pack('iiii',
                                    tcEvent.e1, tcEvent.e2,
                                    tcEvent.e3, tcEvent.e4).rstrip('\000'))#.strip())

    def _HandleExitEvent(self, event):
        # this doesn't work ... exit event occurs while thread is still scheduled
        # self._ThreadDone(event.tid)
        pass

    def _HandlePowerScopeEvent(self, event, trace, useExtra1):
        """Account for time (& power) spent within a scope"""
        self._HandlePowerEvent(event)

        thread = self.threads[event.tid]
        eventKey = event.TraceSignature()
        if useExtra1:
            eventKey += (event.e1,)
        if event.e2 == 1:
            # entering scope
            try:
                thread.ActivateSubBucket(eventKey)
            except KeyError:
                eventName = self.LookupTrace(event).get('name')
                if useExtra1:
                    eventName += "_%d" % event.e1
                thread.CreateSubBucket(eventKey, eventName)
                thread.ActivateSubBucket(eventKey)
        elif event.e2 == 0:
            # exiting scope
            try:
                thread.DeactivateSubBucket(eventKey)
            except KeyError:
                # should only happen at beginning of trace
                sys.stderr.write('WARNING: leaving scope without entering it at sequence %d\n' % \
                                     event.sequence)

    def _ThreadDone(self, tid):
        # tell thread about its parent
        pid = self.threads[tid].pid
        if pid and pid in self.threads:
            self.threads[tid].SetParent(self.threads[pid])
        # move from self.threads to self.defunctThreads
        self.defunctThreads.append(self.threads[tid])
        del self.threads[tid]

    def HandleEvent(self, event):

        # sequence number -1 is a special case which we always pass thru
        # (injected by "trapztool.py capture")
        if event.sequence != -1:
            # bounds check sequence number
            if event.sequence < self.fromSeq or event.sequence > self.toSeq:
                return
            if self.basetime < 0:
               self.basetime = event.timestamp
            relT = event.timestamp - self.basetime
            if relT < self.fromTime or relT > self.toTime:
               return
            # count events
            if self.i > self.n:
                return
            self.i += 1

        if event.category == self.kernCatId:
            if event.compId == self.schedCompId:
                if event.traceId == self.ctxSwTraceId:
                    self._HandleCtxSwEvent(event)
                elif event.traceId == self.tc1TraceId:
                    self._HandleTaskCommEvent(event)
                elif event.traceId == self.exitTraceId:
                    self._HandleExitEvent(event)
            elif event.compId == self.dvfsCompId:
                if event.traceId == self.dvfsTraceId:
                    self._HandleDvfsEvent(event)
            elif self.emitSecureStats:
                if event.compId == self.secCompId:
                    if event.traceId == self.secTraceId:
                        self._HandleSecureEvent(event)

        # handle powerscope events
        if self.emitPowerScopes:
            try:
                trace = self.LookupTrace(event)
            except KeyError:
                pass
            else:
                v = self.LookupTrace(event).get('powerscope')
                if v:
                    self._HandlePowerScopeEvent(event, trace, v=='extra1')

    def Finish(self, prefix=None):
        # XXXmunsal idle thread throws off our data
        del self.threads[0]
        # complete child threads first, to guarantee their parents are still around
        threadList = dict(self.threads)
        for thread in threadList.values():
            if thread.IsChild():
                self._ThreadDone(thread.tid)
        threadList = dict(self.threads)
        # complete all other threads
        for thread in threadList.values():
            self._ThreadDone(thread.tid)


        # threads we care about are those with at least one context switch
        resultThreads = [t for t in self.defunctThreads if t.switches]
        # print "%d total threads, %d active threads" % (len(self.defunctThreads), len(resultThreads))

        # results by thread in resultThreads
        resultThreads.sort(key=lambda t: t.GetEnergy(), reverse=True)

        # here are results by processes:
        processes = [t.GetProcess() for t in resultThreads if not t.IsChild()]
        processes.sort(key=lambda t: t.GetEnergy(), reverse=True)

        # here are results by process name
        processByName = {}
        for p in processes:
            processByName.setdefault(p.name, []).append(p)
        for (name, procs) in processByName.items():
            processByName[name] = PowerThread(None, None, name, children=procs)
        processByName = processByName.values()
        processByName.sort(key=lambda t: t.GetEnergy(), reverse=True)

        print self.Results(resultThreads)

        if prefix:
            threadCsvFile = open(prefix + '_thread.csv', 'w')
            threadCsvFile.write(self.Results(resultThreads, csv=True))
            threadCsvFile.close()

            processCsvFile = open(prefix + '_process.csv', 'w')
            processCsvFile.write(self.Results(processes, csv=True))
            processCsvFile.close()

            nameCsvFile = open(prefix + '_name.csv', 'w')
            nameCsvFile.write(self.Results(processByName, csv=True))
            nameCsvFile.close()

class TrapzXmlEnumerator(SimpleTrapz):
    """This class adds the Enumerate() function to TrapzXmlValidator [now
    SimpleTrapz]. Enumerate() generates and fills in any missing categories,
    IDs, etc. A tree which might not pass Validate() before you call
    Enumerate(), should pass Validate() after you call Enumerate()."""

    def __init__(self):
        TrapzXmlParser.__init__(self)

    def Parse(self, xmlFile):
        # Do NOT call TrapzXmlValidator.Parse()... we have to
        # enumerate BEFORE we validate.  Instead we call the base
        # class Parse().
        TrapzXmlParser.Parse(self, xmlFile)
        self.Enumerate()        # then enumerate
        self.Validate()        # then validate

    def Enumerate(self):
        # The next component ID. Starts at 0, incremented as components are
        # allocated. Existing component IDs in XML file will restart the
        # counter at that value.
        self.curCompId = 0
        # The next available trace ID for each component, indexed by component
        # id.  Starts at zero, incremented as traces are allocated.  Existing
        # trace IDs in XML file will restart the counter at that value.
        self.curTraceId = {}

        self.Traverse(self.root, preProcess=self._EnumerateElement)

    def _EnumerateElement(self, path):
        if path[-1].tag == 'component':
            self._EnumerateComponent(path)
        elif path[-1].tag == 'trace':
            self._EnumerateTrace(path)
        elif path[-1].tag in set(['trapz','scan','description','event']):
            pass
        else:
            raise AssertionError

    def _EnumerateComponent(self, path):
        element = path[-1]

        if 'id' in element.keys():
            # update current component ID so that new components are assigned
            # higher ID numbers
            compId = int(element.get('id'))
            if (compId > self.curCompId):
                self.curCompId = compId
        else:
            # assign curCompId to this component ID
            compId = self.curCompId
            element.set('id', str(self.curCompId))

        # reset trace ID for this component
        self.curTraceId[compId] = 0

        # increment curCompId for generating next component
        self.curCompId = self.curCompId + 1

        # if name is missing, warn about it and use full symbol
        if element.get('name') == None:
            sys.stderr.write('WARNING: using %s for missing name\n' % fullSymbol)
            element.set('name', fullSymbol)

        # if we don't have category, inherit parent's category
        if element.get('cat') == None:
            try:
                parentCategory = path[-2].get('cat')
            except IndexError:
                parentCategory = str(TrapzEvent.CAT_UNKNOWN)
            element.set('cat', parentCategory)

    def _EnumerateTrace(self, path):
        element = path[-1]

        # determine component id of this trace using our parent
        compId = int(path[-2].get('id'))

        if 'id' in element.keys():
            # update current trace ID so that new traces are assigned higher ID
            # numbers
            traceId = int(element.get('id'))
            if (traceId > self.curTraceId[compId]):
                self.curTraceId[compId] = traceId
        else:
            # assign curTraceId to this trace ID
            element.set('id', str(self.curTraceId[compId]))

        self.curTraceId[compId] = self.curTraceId[compId] + 1


class TrapzXmlVcd(TrapzXmlEnumerator):
    """This is a version of TrapzXmlParser which is used to generate
    the component heirarchy for the VCD writer.

    In __init__, we parse the XML and then validate it

    AddTrace() looks for a given trace in the parse tree. It adds it
    if it's not found (also adding any components if necessary). Then
    it sets the 'inUse' attribute on the trace.

    WriteVcd() traverses the tree again to propogate the 'inUse'
    attribute from traces up through their parent components. Then it
    traverse the tree a final time, telling the VCD writer to emit
    scopes for any components we're using, and variables for any
    traces."""

    # These are the signal types we support in VCD file.
    # IMPULSE_SIGNAL is a 1ns pulse every time the event occurs
    # EXTRA1_EVENT and EXTRA2_EVENT are integer values from the log event
    # SCOPE_SIGNAL goes high when scope is entered (extra2 == 1), low when
    # scope is exited (extra2 == 0), and undefined (X) when scope is exited
    # abnormally (any other value).
    # PRINTF_SIGNAL contains the printf string from an event.
    # DELTA_SIGNAL contains the time difference between this and the *next*
    # occurance of the event.
    (IMPULSE_SIGNAL, EXTRA1_SIGNAL, EXTRA2_SIGNAL, SCOPE_SIGNAL, PRINTF_SIGNAL, DELTA_SIGNAL) = range(6)

    def __init__(self, vcdWriter,
                 emitHierarchy=True, emitDeltas=True, emitCounts=True, emitPrintfs=True, emitExtras=True,
                 emitTidTraces=True, emitCpuTraces=True, emitSched=True, emitSchedCmds=True,
                 emitPowerReport=True):

        TrapzXmlValidator.__init__(self)
        self.vcdWriter = vcdWriter

        self.emitHierarchy = emitHierarchy
        self.emitDeltas = emitDeltas
        self.emitCounts = emitCounts
        self.emitPrintfs = emitPrintfs
        self.emitExtras = emitExtras
        self.emitTidTraces = emitTidTraces
        self.emitCpuTraces = emitCpuTraces
        self.emitSched = emitSched
        self.emitSchedCmds = emitSchedCmds
        self.emitPowerReport = emitPowerReport

        # Keep track of the timestamp of the most recent event on each trace in
        # order to calculate deltas. Indexed by the trace's VCD ID string.
        self.lastEvent = {}

        # Keep track of the cumulative number of times this event has been seen
        self.eventCount = {}

        # Keep track of all extra vcdId suffixes for per-TID traces. Indexed by
        # VCD ID.
        self.tidSuffixes = {}
        # Keep track of all extra vcdId suffixes for per-CPU traces. Indexed by
        # VCD ID.
        self.cpuSuffixes = {}

        # These are additional events parsed out of PVRTune CSV trace
        self.pvrEvents = []

        # Accumulated dict of discovered logcat signal names
        self.logCatSignals = {}

    def ParsePvrTune(self, pvrTuneFile, showProgress=False):

        import math

        pvrData = pvrTuneFile.read()
        pvrTuneFile.close()

        pvrLines = pvrData.split('\n')
        self.pvrEvents = [tuple([x.strip() for x in l.split(',') if x.strip()]) for l in pvrLines]

        # check event validity
        self.pvrEvents = [l for l in self.pvrEvents if (len(l) and
                                                        l[0].isdigit() and
                                                        l[1] in set(['ta_start', 'ta_end', '3d_start', '3d_end']) and
                                                        l[2].isdigit())]

        if showProgress:
            print "Read %d events from PvrTune file" % len(self.pvrEvents)

        if len(self.pvrEvents):
            # find component for PVRTune events
            pvrComponent = self.rootComponent.find(".//component[@name='PvrTune']")

            # add TA and 3D traces to this component
            # we could rely on AddAllEventsToVcd to add traces for us, but:
            # 1) they wouldn't be named traces
            # 2) they wouldn't be scope traces
            for (traceId, traceSymbol) in [(0, '3D'), (1, 'TA')]:
                trace = ElementTree.Element('trace')
                trace.set('cat', pvrComponent.get('cat'))
                trace.set('id', str(traceId))
                trace.set('name', 'pvr%s' % traceSymbol)
                trace.set('symbol', traceSymbol)
                trace.set('scope', str(1))
                pvrComponent.append(trace)
                self._ValidateTrace([None, pvrComponent, trace]) # as in AddTraceForEvent()

            # find starting and ending timestamp in trapz event log
            allTs = [e.timestamp for e in self.GenerateEvents()]
            trapzStartTs = min(allTs)
            trapzEndTs = max(allTs)
            # This is the amount of time it takes in nanoseconds for PVRTune
            # timestamps to wrap. PVRTune uses microseconds since 1970 as
            # returned by gettimeofday(), truncated to 32 bits.
            wrapInterval = 2**32 * 1000
            # this is the number of wraps in startTs and endTs
            trapzStartWraps = int(math.floor(trapzStartTs/wrapInterval))
            trapzEndWraps = int(math.ceil(trapzEndTs/wrapInterval))

            # convert pvrEvents to TrapzEvents
            prevTimestamp = None
            # For now we blithely assume that PVR timer hasn't wrapped
            # between first TRAPZ timestamp and first PVR timestamp.
            wrapCount = trapzStartWraps
            for (iPvrEvent, (timestampStr, eventStr, pidStr)) in enumerate(self.pvrEvents):
                event = TrapzEvent()
                event.sequence = iPvrEvent # but this overlaps with Trapz sequence number
                event.cpu = 9 # let's say 9 is gpu
                event.pid = event.tid = pidStr
                event.level = 1 # whatever
                event.category = pvrComponent.get('cat')
                event.compId = pvrComponent.get('id')
                event.e1 = 0
                if eventStr == 'ta_start':
                    event.traceId = 1
                    event.e2 = 1
                elif eventStr == 'ta_end':
                    event.traceId = 1
                    event.e2 = 0
                elif eventStr == '3d_start':
                    event.traceId = 0
                    event.e2 = 1
                elif eventStr == '3d_end':
                    event.traceId = 0
                    event.e2 = 0
                # Timestamp is in microseconds, convert to nanoseconds
                timestamp = int(timestampStr) * 1000
                # Timestamps should be monotonically increasing, so if they
                # decrease we know there is a wrap in PVR log.
                if timestamp < prevTimestamp:
                    wrapCount += 1
                prevTimestamp = timestamp
                timestamp += wrapCount * wrapInterval
                event.timestamp = timestamp
                self.events.append(event)

# clean up a line of text from the logcat file by filtering out all ASCII control characters and
# all characters outside of the 7-bit ASCII range. Convert spaces to underscores.
    @staticmethod
    def cleanUp(lineIn):
        cleaned = ''
        for c in lineIn:
            asI = ord(c)
            if asI >= 0x20 and asI <= 0x7f:
               if asI == 0x20:
                   cleaned = cleaned + '_'
               else:
                   cleaned = cleaned + c
        return cleaned

# parse thru a logcat file, finding lines with timestamps in range.
# these are then converted into pseudo-events with string values
# which have internal spaces replaced with underscores so gtkwave will
# display them in traces and mouseovers
    def ParseLogCat(self, pvrLogCat):

     import math

     print ("Processing logcat data")

     yearVal = time.localtime().tm_year

     # find starting and ending timestamp in trapz event log
     allTs = [e.timestamp for e in self.GenerateEvents()]
     lastTS = 0
     lastTSoff = 0
     trapzStartTs = min(allTs)
     trapzEndTs = max(allTs)
     lineCtr = 1
     signalCtr = 1
     labelPosInCatLine = 0
     stripTwo = False
     for catLine in pvrLogCat:
        catLine = catLine.strip()
        if catLine != '':
          if not catLine.startswith('-'):
             catLine = str(catLine)
             dateTime = catLine.split()
             dateT = dateTime[0].split('-')
             timeT = dateTime[1].split(':')
             secs = timeT[2].split('.')
             itemTime = int(time.mktime((yearVal, int(dateT[0]), int(dateT[1]), int(timeT[0]), int(timeT[1]), int(secs[0]), 0, 0, -1))) * 1000000000 + int(secs[1]) * 1000000
             if (itemTime >= trapzStartTs) and (itemTime <= trapzEndTs):
                 # replace spaces, tabs, & bad unicode character indications
                 # lineFixed1 = catLine.replace(' ', '_')
                 # lineFixed2 = lineFixed1.replace('\t','_')
                 # lineFixed3 = lineFixed2.replace(zonker,'_')
                 lineLen = catLine.__len__()
                 if lineLen > 1024:
                      lineTrimmed = catLine[:1023]
                 else:
                      lineTrimmed = catLine
                 lineFixed = self.cleanUp(lineTrimmed)

                 # space log lines with identical times out in 10 usec intervals
                 if itemTime == lastTS:
                     itemTime = itemTime + lastTSoff
                     lastTSoff += 10000
                 else:
                     lastTS = itemTime
                     lastTSoff = 0
                 # find the first word position that is non-numeric. This skips TID and PID if present.
                 if labelPosInCatLine == 0: # only consider this logic once.
                       labelPosInCatLine = 2
                       while dateTime[labelPosInCatLine].isdigit():
                           labelPosInCatLine = labelPosInCatLine + 1
                       if dateTime[labelPosInCatLine].__len__() == 1:
                           labelPosInCatLine = labelPosInCatLine + 1
                       sampleCat = dateTime[labelPosInCatLine]
                 # also determine if we should strip the priority prefix from in front of the name.
                       if sampleCat.__len__() > 2:
                          if sampleCat[1] == '/':
                             stripTwo = True;

                 catName = dateTime[labelPosInCatLine]
                 catName = catName.replace('.','_')
                 catName = catName.replace(':','')
                 catName = catName.replace('(','')
                 catName = catName.replace(')','')
                 catName = catName.replace(' ','')
                 catName = catName.replace('!','')
                 if stripTwo:
                     catName = catName[2:]

                 if catName in self.logCatSignals:
                     signalNum = self.logCatSignals[catName]
                 else:
                     signalNum = signalCtr
                     self.logCatSignals[catName] = signalCtr
                     signalCtr = signalCtr + 1
                 event = TrapzEvent()
                 event.sequence = lineCtr
                 event.cpu = 0
                 event.pid = event.tid = 0
                 event.level = 1 # whatever
                 event.e1 = 0
                 event.e2 = 0
                 event.category = 3
                 event.compId = 1
                 event.timestamp = itemTime
                 event.traceId = 0
                 event.logcat = lineFixed
                 self.events.append(event)
                 if catName.__len__() > 0:
                    event2 = TrapzEvent()
                    event2.sequence = lineCtr
                    event2.cpu = 0
                    event2.pid = event2.tid = 0
                    event2.level = 1 # whatever
                    event2.e1 = 0
                    event2.e2 = 0
                    event2.category = 3
                    event2.compId = 1
                    event2.timestamp = itemTime
                    event2.traceId = 0
                    event2.catname = catName
                    event2.logcat = lineFixed
                    self.events.append(event2)
             lineCtr = lineCtr + 1

     print(lineCtr)
     pvrLogCat.close()
     return


    def AddAllEventsToVcd(self, showProgress=False):
        # Process events one by one, updating XML tree with new traces as we go
        if showProgress:
            print "Converting TRAPZ events to VCD events"

        for event in self.GenerateEvents(showProgress):
            self.AddEventToVcd(event)

        if showProgress:
            print

        if self.emitSched:
            self.AddSchedTraces(showProgress)


    def AddEventToVcd(self, event):
        """Adds an event to the VCD file."""

        # This trace should already be in generated XML. However we might not be
        # using generated XML or the user might have done ad-hoc tracing to
        # random trace IDs that aren't in the XML, in which case we add the
        # trace here.
        try:
            trace = self.LookupTrace(event)
        except KeyError:
            # We need to add the trace.
            # First look up the component for this trace
            try:
                component = self.LookupComponent(event)
            except KeyError:
                # Yikes! We don't just need to add the trace, we need to add
                # the component too! This is an ad-hoc component not in XML
                sys.stderr.write('Warning: undeclared component (%s, %s)\n' \
                                     % (event.category, event.compId))
                # Find the top level component with this category to be
                # the parent for the new category.
                parent = None
                for topLevel in self.rootComponent.findall('component'):
                    if int(topLevel.get('cat')) == event.category:
                        parent = topLevel
                # now add the new component
                component = self.AddComponentForEvent([self.root, parent], event)

            # Add new trace. Create its name using parent component's name.
            trace = self.AddTraceForEvent(component, event)

        trace.set('inUse', '1') # so we don't emit unused components in VCD file

        vcdId = trace.get('vcdId')
        baseVcdId = vcdId

        # add per-tid traces if requested
        if self.emitTidTraces and trace.get('perTid'):
            tidSuffix = '_Tid%d' % event.tid
            self.tidSuffixes.setdefault(baseVcdId, set()).add(tidSuffix)
            vcdId += tidSuffix

        # add per-cpu traces if requested
        if self.emitCpuTraces and trace.get('perCpu'):
            cpuSuffix = '_Cpu%d' % event.cpu
            self.cpuSuffixes.setdefault(baseVcdId, set()).add(cpuSuffix)
            vcdId += cpuSuffix

        try:
           logcat = event.logcat
        except AttributeError:
           pass
        else:
           self.vcdWriter.Event(event.timestamp, vcdId, logcat)
           return
        # Scope traces override the normal tracing of event impulses and
        # extra1/extra2
        if trace.get('scope'): # scope traces will be marked as such

            # generate scope signal
            # extra2 contains scope entry/exit/fail.
            if str(event.e2) in VcdWriter.BINARY_VALUES:
                self.vcdWriter.Event(event.timestamp, vcdId, str(event.e2))
            else:
                assert event.e2 == -1
                self.vcdWriter.Event(event.timestamp, vcdId, 'X')

            # generate extra1 signal -- it may have ancillary data
            if self.emitExtras:
                # If extra data is nonzero now, enable tracing
                if event.e1:
                    trace.set('extra1', '1')
                if event.e3:
                    trace.set('extra3', '1')
                if event.e4:
                    trace.set('extra4', '1')
                # If extra data was EVER nonzero, add an event
                if trace.get('extra1'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e1', str(event.e1))
                if trace.get('extra3'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e3', str(event.e3))
                if trace.get('extra4'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e4', str(event.e4))

        else:

            # generate an impulse for the event itself
            # VcdWriter takes care of making sure events aren't superimposed
            self.vcdWriter.Event(event.timestamp, vcdId, '1')
            self.vcdWriter.Event(event.timestamp, vcdId, '0')

            # generate extra signals
            if self.emitExtras:
                # If extra data is nonzero now, enable tracing
                if event.e1:
                    trace.set('extra1', '1')
                if event.e2:
                    trace.set('extra2', '1')
                if event.e3:
                    trace.set('extra3', '1')
                if event.e4:
                    trace.set('extra4', '1')
                # If extra data was EVER nonzero, add an event
                if trace.get('extra1'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e1', str(event.e1))
                if trace.get('extra2'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e2', str(event.e2))
                if trace.get('extra3'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e3', str(event.e3))
                if trace.get('extra4'):
                    self.vcdWriter.Event(event.timestamp, vcdId + '_e4', str(event.e4))

        # generate printf signal
        if self.emitPrintfs:
            # if we have a format string, write an event for it
            formatString = trace.get('formatString')
            if formatString:
                formatStringVarCount = trace.get('formatStringVarCount')
                if formatStringVarCount is None:
                    formatStringVarCount = len(formatString.split('%')) - 1
                    trace.set('formatStringVarCount', formatStringVarCount)

                # create the list of printf args
                formatStringArgs = list()
                formatStringArgs.append(event.e1)
                if formatStringVarCount > 1:
                    formatStringArgs.append(event.e2)
                if formatStringVarCount > 2:
                    formatStringArgs.append(event.e3)
                if formatStringVarCount > 3:
                    formatStringArgs.append(event.e4)

                # replace whitespace in format with underscores
                formatString = '_'.join(formatString.split())
                try:
                    formatString = formatString % tuple(formatStringArgs)
                except TypeError as e:
                    sys.stderr.write('Warning: Could not format "%s" - %s\n' % (formatString, e))
                    pass
                self.vcdWriter.Event(event.timestamp, vcdId + '_printf', formatString)

        # generate count signal
        if self.emitCounts:
            self.eventCount[vcdId] = self.eventCount.get(vcdId, 0) + 1
            self.vcdWriter.Event(event.timestamp, vcdId + '_count', str(self.eventCount[vcdId]))

        # generate delta signal
        if self.emitDeltas:
            try:
                lastTime = self.lastEvent[vcdId]
            except KeyError:
                pass
            else:
                # We need to insert an event at the *previous* timestamp with
                # the delta between that time and the current time. The event
                # list is sorted before we write the VCD file so it's OK that we
                # are generating these out of order. The value of the trace is
                # expressed in milliseconds to make it readable.
                deltaInMs = float(event.timestamp - lastTime)/1E6
                self.vcdWriter.Event(lastTime,
                                     vcdId + '_delta',
                                     '%g' % deltaInMs)
            self.lastEvent[vcdId] = event.timestamp


    def AddSchedTraces(self, showProgress=False):
        """This started as a function to add traces to VCD showing when
        different threads were active based on scheduler trace point. It has
        grown to include a bunch of code for simulation / statistics related to
        scheduler trace point."""

        if showProgress:
            print "Emitting scheduler traces"

        ctxSwEvents = self.filterEvents("Scheduler", "CtxSw")
        if not len(ctxSwEvents):
            print "No context switch events"
            return
        
        dvfsTrace = self.getIds("DVFS", "DVFSChangeFreq")

        # Context switches are special.  The to tid is split across e1 and e2.
        tids = set()
        cpus = set()
        for event in ctxSwEvents:
            tids.add(event.tid)
            tids.add((event.e2 << 8) & (event.e1))
            cpus.add(event.cpu)

        # we need DVFS events to calculate power consumption per thread
        dvfsEvents = self.filterEvents("DVFS", "DVFSChangeFreq")

        # Let's call the combination of ctxsw and dvfs events "scheduler
        # events". Its not really a good name but I can't come up with a better
        # one.
        schedEvents = ctxSwEvents + dvfsEvents
        schedEvents.sort()

        # Component tree for scheduler data
        schedComponent = ElementTree.Element('component')
        schedComponent.set('name', 'SchedulerData')
        schedComponent.set('inUse', '1')
        self.rootComponent.append(schedComponent)

        cpuComponent = ElementTree.Element('component')
        cpuComponent.set('name', 'CpuData')
        cpuComponent.set('inUse', '1')
        schedComponent.append(cpuComponent)

        processComponent = ElementTree.Element('component')
        processComponent.set('name', 'ProcessActive')
        processComponent.set('inUse', '1')
        schedComponent.append(processComponent)

        processCpuComponent = ElementTree.Element('component')
        processCpuComponent.set('name', 'ProcessWhichCpu')
        processCpuComponent.set('inUse', '1')
        schedComponent.append(processCpuComponent)

        processPowerComponent = ElementTree.Element('component')
        processPowerComponent.set('name', 'ProcessPower')
        processPowerComponent.set('inUse', '1')
        schedComponent.append(processPowerComponent)

        processCountComponent = ElementTree.Element('component')
        processCountComponent.set('name', 'ProcessCount')
        processCountComponent.set('inUse', '1')
        schedComponent.append(processCountComponent)

        processElapsedComponent = ElementTree.Element('component')
        processElapsedComponent.set('name', 'ProcessElapsed')
        processElapsedComponent.set('inUse', '1')
        schedComponent.append(processElapsedComponent)

        tidName = {} # map tid to /proc/<pid>/task/<tid>/comm, 16 character truncated task name
        tidParentPid = {} # map tid to ppid
        if self.emitSchedCmds:
            (tidName, tidParentPid) = ScrapeProc()

        # Pull task names out of scheduler event stream. I am going to go ahead
        # and assume that PIDs don't wrap during the duration of the log
        # capture so we don't need to worry about reusing PIDs.
        tcEvents = self.filterEvents("Scheduler", "TaskComm")
        for (tcEvent) in tcEvents:
            # rstrip nulls because thread name from TRAPZ will be null terminated
            tidName[tcEvent.tid] = struct.pack('iiii',
                                                tcEvent.e1, tcEvent.e2,
                                                tcEvent.e3, tcEvent.e4).rstrip('\000')#.strip()
            tidParentPid[tcEvent.tid] = tcEvent.pid

        # verilogify all tid names
        tidVerilogName = {}
        for tid in tidName.keys():
            tidVerilogName[tid] = VcdWriter.Verilogify(tidName[tid])

        tidTraceName = {} # map tid to VCD trace name
        for tid in tids:
            if tid in tidName:
                if tidParentPid[tid] == tid:
                    # this is process group leader, short trace name
                    tidTraceName[tid] = "_%d_%s" % (tid, tidVerilogName[tid])
                else:
                    # long trace name including parent pid's name as well as ours
                    tidTraceName[tid] = "_%d_%s_%s" % (tid, tidVerilogName[tidParentPid[tid]],
                                                       tidVerilogName[tid])
            else:
                tidTraceName[tid] = "_%d" % tid

        for tid in tids:
            for (traceName, comp) in ((tidTraceName[tid], processComponent),
                                      (tidTraceName[tid] + '_Cpu', processCpuComponent),
                                      (tidTraceName[tid] + '_Power', processPowerComponent),
                                      (tidTraceName[tid] + '_Count', processCountComponent),
                                      (tidTraceName[tid] + '_Elapsed', processElapsedComponent)):
                trace = ElementTree.Element('trace')
                trace.set('name', traceName)
                trace.set('vcdId', traceName)
                trace.set('inUse', '1')
                comp.append(trace)

        for cpu in cpus:
            for traceName in ("Cpu_%d_ThreadName" % cpu, "Cpu_%d_ProcessName" % cpu, "Cpu_%d_Tid" % cpu, "Cpu_%d_Idle" % cpu):
                trace = ElementTree.Element('trace')
                trace.set('name', traceName)
                trace.set('vcdId', traceName)
                trace.set('inUse', '1')
                cpuComponent.append(trace)

        # track per-tid scheduler statistics
        tidPower = {} # map tid to cumulative power consumption by thread
        tidElapsed = {} # map tid to the cumulative amount of time it has been scheduled
        tidCount = {} # map tid to the number of times it has been scheduled
        for tid in tids:
            tidPower[tid] = 0.
            tidElapsed[tid] = 0.
            tidCount[tid] = 0
        cpuCurrentTid = {}
        cpuLastSchedTime = {}
        for cpu in cpus:
            cpuCurrentTid[cpu] = 0 # idle
            cpuLastSchedTime[cpu] = 0

        exitEvents = self.filterEvents("Scheduler", "Exit")
        for event in exitEvents:
            # for now just a proof of concept
            # set tid trace to X when it exits
            # these are totally out of order but VcdWriter sorts its events
            # exit trapz stores pid in e1, tid in e2
            self.vcdWriter.Event(event.timestamp, tidTraceName[event.e2], 'X')

        dvfsFreq = 1200000000 # 1.2 GHz default

        for event in schedEvents:

            # Do power bookkeeping on any scheduler event, whenever CPU is non-idle.
            # This brings our bookkeeping up to date for the period between the last
            # schedEvent and this one.
            for cpu in cpus:
                currentTid = cpuCurrentTid[cpu]
                if currentTid != 0:
                    # Update tidPower to reflect power consumed by current
                    # thread between last scheduler event and this one.
                    tidPower[currentTid] += PowerConsumed(event.timestamp - cpuLastSchedTime[cpu], # elapsed
                                                          dvfsFreq)         # frequency

                    # Add event updating current tid's power consumption
                    self.vcdWriter.Event(event.timestamp, tidTraceName[currentTid] + '_Power',
                                         ("%f" % tidPower[currentTid]).rstrip('0'))

                    # Add event updating current tid's elapsed time (run time).
                    # Record elapsed times as integer nanoseconds, write to VCD
                    # as floating point seconds
                    tidElapsed[currentTid] += event.timestamp - cpuLastSchedTime[cpu]
                    self.vcdWriter.Event(event.timestamp, tidTraceName[currentTid] + '_Elapsed',
                                         ("%f" % (tidElapsed[currentTid]/1000000000.)).rstrip('0'))

                cpuLastSchedTime[cpu] = event.timestamp

            if event.category == dvfsTrace[0] and event.compId == dvfsTrace[1] and event.traceId == dvfsTrace[2]:
                # this is a DVFS (frequency change) event
                dvfsFreq = event.e1
                # done with this event
                continue
            
            from_tid = event.tid
            to_tid = (event.e2 << 8) | (event.e1)

            # increment ctxsw count for the tid we are switching to
            tidCount[to_tid] += 1

            # update current tid for this cpu
            cpuCurrentTid[event.cpu] = to_tid

            self.vcdWriter.Event(event.timestamp, tidTraceName[from_tid], '0')
            self.vcdWriter.Event(event.timestamp, tidTraceName[to_tid], '1')
            self.vcdWriter.Event(event.timestamp, tidTraceName[from_tid] + '_Cpu', 'X')
            self.vcdWriter.Event(event.timestamp, tidTraceName[to_tid] + '_Cpu', str(event.cpu))
            self.vcdWriter.Event(event.timestamp, tidTraceName[to_tid] + '_Count', str(tidCount[to_tid]))
            self.vcdWriter.Event(event.timestamp, "Cpu_%d_Tid" % event.cpu, str(to_tid))
            if from_tid == 0 and to_tid != 0:
                # no longer idle
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_Idle" % event.cpu, '0')
            elif to_tid == 0 and from_tid != 0:
                # becoming idle
               self.vcdWriter.Event(event.timestamp, "Cpu_%d_Idle" % event.cpu, '1')
            if to_tid in tidName:
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_ThreadName" % event.cpu,
                                     tidVerilogName[to_tid])
            elif to_tid == 0:
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_ThreadName" % event.cpu, "<idle>")
            else:
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_ThreadName" % event.cpu, "<unknown>")
            if to_tid in tidParentPid and tidParentPid[to_tid] in tidName:
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_ProcessName" % event.cpu,
                                     tidVerilogName[tidParentPid[to_tid]])
            elif to_tid == 0:
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_ProcessName" % event.cpu, "<idle>")
            else:
                self.vcdWriter.Event(event.timestamp, "Cpu_%d_ProcessName" % event.cpu, "<unknown>")

        if showProgress:
            print

        if self.emitPowerReport:
            tidPowerList = [(power, tid) for (tid, power) in tidPower.items()]
            tidPowerList.sort()
            tidPowerList.reverse() # from high to low power

            # totalTime = (self.events[-1].timestamp - self.events[0].timestamp) / 1E9
            # XXXmunsal unfortunately this is only partly converted to use
            # governors / streaming events... so this is HORRIBLE
            events = self.GenerateEvents()
            try:
                startTime = -1
                while startTime < 0:
                    event = next(events)
                    startTime = event.timestamp
                while True:
                    event = next(events)
            except StopIteration:
                endTime = event.timestamp
            totalTime = (endTime - startTime) / 1E9

            print
            print "Total time: %8.4f seconds" % totalTime
            print
            print "Joules   Avg mA   CPUTime  Load   Tid   Pid   TidName          PidName"
            print "======== ======== ======== ====== ===== ===== ================ ================"
            for (power, tid) in tidPowerList:
                print "%8.4f %8.4f %8.4f %5.2f%%" % (power,
                                                     power / totalTime / 3.7 * 1000.,
                                                     (tidElapsed[tid] / 1000000000.),
                                                     (tidElapsed[tid] / 1000000000. / totalTime * 100)),

                if tid in tidParentPid:
                    print "%5d %5d %16s %16s" % (tid,
                                                 tidParentPid[tid],
                                                 tidName.get(tid, ""),
                                                 tidName.get(tidParentPid[tid], ""))
                else:
                    print "%5d       %16s" % (tid,
                                              tidName.get(tid, ""))

    def WriteVcd(self, showProgress=False):
        if showProgress:
            print "Writing VCD vars"
        self._WriteVcdVars()
        self.vcdWriter.Finish(showProgress)

    def _WriteVcdVars(self):
        # Traverse to propogate inUse flag from children to parents
        self.Traverse(self.rootComponent, preProcess=self._InUseHelper)
        # Traverse to actually write heirarchy of in-use traces
        self.Traverse(self.rootComponent,
                      preProcess=self._WriteVcdVarsHelper,
                      postProcess=self._WriteVcdVarsPostHelper)

    def _InUseHelper(self, path):
        # yes this is inefficient, no I don't care
        # if we're in use...
        if path[-1].get('inUse'):
            # ...set all of our ancestors to be in use
            for e in path[:-1]:
                e.set('inUse', '1')

    def _WriteVcdVarsHelper(self, path):
        element = path[-1]
        if not element.get('inUse'):
            return
        if element.tag == 'component':
            if self.emitHierarchy:
                self.vcdWriter.PushScope(element.get('name'))
        elif element.tag == 'trace':
            vcdId = element.get('vcdId')
            name = element.get('name')
            tidSuffixes = set(['']) | self.tidSuffixes.get(vcdId, set())
            cpuSuffixes = set(['']) | self.cpuSuffixes.get(vcdId, set())

            for suffix in [tid+cpu for tid in tidSuffixes for cpu in cpuSuffixes]:
                self.vcdWriter.WriteVar(vcdId + suffix, name + suffix)
                if self.emitDeltas:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_delta', name + suffix + '_delta')
                if self.emitCounts:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_count', name + suffix + '_count')
                if element.get('formatString') and self.emitPrintfs:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_printf', name + suffix + '_printf')
                if element.get('extra1') and self.emitExtras:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_e1', name + suffix + '_e1')
                if element.get('extra2') and self.emitExtras:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_e2', name + suffix + '_e2')
                if element.get('extra3') and self.emitExtras:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_e3', name + suffix + '_e3')
                if element.get('extra4') and self.emitExtras:
                    self.vcdWriter.WriteVar(vcdId + suffix + '_e4', name + suffix + '_e4')
        else:
            raise AssertionError

    def _WriteVcdVarsPostHelper(self, path):
        element = path[-1]
        if not element.get('inUse'):
            return
        if element.tag == 'component':
            if self.emitHierarchy:
                self.vcdWriter.PopScope()

class TrapzHeaderGenerator(TrapzXmlEnumerator):

    PRE_TEXT = """\
/**
 * TRAPZ COMPONENT DEFINITIONS
 *
 * THIS FILE IS AUTOMATICALLY GENERATED. DO NOT MODIFY.
 * This file was generated by the following command line:
 *
 * %s
 *
 */

#ifndef _TRAPZ_GENERATED_H
#define _TRAPZ_GENERATED_H 1

"""  % ' '.join(sys.argv)

    POST_TEXT = """\

#endif /* _TRAPZ_GENERATED_H */
"""
    # !! must match the marker text node in trapz.xml
    PLAT_REGISTRY_SPLIT_TEXT = "PLAT-REGISTRY-COMPONENTS-HERE"
    APP_REGISTRY_SPLIT_TEXT = "APP-REGISTRY-COMPONENTS-HERE"

    def __init__(self, category=None, kernel_dir=None):
        TrapzXmlEnumerator.__init__(self)
        self.category = category
        self.kernel_dir = kernel_dir
        self.reTrapz = re.compile(r'TRAPZ_(LOG|LOG_PRINTF|LOG_ENTER|LOG_EXIT|LOG_FAIL|LOG_BEGIN|LOG_END|LOG_SCOPE|DESCRIBE)\((.*?)\)', re.DOTALL)

    def Scan(self, home=sys.path[0]):
        """Scan codebase for TRAPZ_LOG macros, and use them to add
        trace elements to XML parse tree"""
        self.home = home
        # keep track of directories already scanned, avoid rescanning
        self.scanned = set()
        self.Traverse(self.rootComponent, preProcess=self._ScanComponent, tagFilter='component')

    def _ScanComponent(self, path):
        component = path[-1]
        compId = int(component.get('id'))

        # XML element <scan dir="foo/bar"> tells us scan that directory for code with traces
        for scanElement in component.findall("scan"):
            scanDir = scanElement.get('dir')
            if scanDir == "kernel":
                if self.kernel_dir:
                    scanDir = self.kernel_dir
            # prepend home dir to any non-absolute paths
            if not os.path.isabs(scanDir):
                scanDir = os.path.abspath(os.path.join(self.home, scanDir))
            if not os.path.isdir(scanDir):
                sys.stderr.write('WARNING: directory not found for scan element: %s\n' % scanDir)
            for root, dirs, files in os.walk(scanDir, followlinks=True):
                if root in self.scanned:
                    continue
                self.scanned.add(root)
                # ignore everything but C source files
                files = [os.path.join(root, f) for f in files if fnmatch(f, '*.c') or fnmatch(f, '*.cpp') or fnmatch(f, '*.cc')]
                for f in files:
                    if os.path.basename(f).startswith('.#'):
                        # definitely skip this EMACS trash
                        continue
                    self._ScanFile(f)

    def _ScanFile(self, fileName):
        # Regular expressions simply aren't powerful enough to properly parse C syntax.
        # But for now, this will have to work. XXXmunsal
        f = open(fileName, 'r')
        try :
            m = mmap.mmap(f.fileno(), 0, prot=mmap.PROT_READ)
        except:
            matches = re.findall(self.reTrapz, f.read())
        else:
            matches = re.findall(self.reTrapz, m.read(m.size()))
            m.close()
        f.close()

        for (macro, argString) in matches:
            args = argString.split(',')
            args = [arg.strip() for arg in args]
            expectedArgCount = {'DESCRIBE' : 3,
                                'LOG': 8,
                                'LOG_PRINTF': 9,
                                'LOG_ENTER': 4,
                                'LOG_EXIT': 4,
                                'LOG_FAIL': 4,
                                'LOG_BEGIN': 4,
                                'LOG_SCOPE': 4,
                                'LOG_END': 4 }   [macro]
            if len(args) != expectedArgCount:
                sys.stderr.write("ERROR: Failed to parse %s(%s) in file %s\n" \
                                         % (macro, argString, fileName))
                sys.stderr.write("Look for spurious commas or parentheses (see TT-1528 in JIRA for more info)\n")
                exit(1)

            if macro == 'DESCRIBE':
                (compFullSym, traceSym) = args[0:2]
            else:
                (compFullSym, traceSym) = args[2:4]

            # look up the component identified by compFullSym
            try:
                targetComponent = self.componentsByFullSymbol[compFullSym]
            except KeyError:
                sys.stderr.write("ERROR: Unrecognized component %s in file %s\n" \
                                     % (compFullSym, fileName))
                exit(1)

            targetComponentId = int(targetComponent.get('id'))

            # see if we've already added this trace
            # XXXmunsal this should work:
            #    trace = targetComponent.find("./trace[@name='%s']" % traceSym)
            # but it doesn't
            trace = None
            for t in targetComponent.findall('trace'):
                if t.get('name') == traceSym:
                    trace = t
                    break

            if trace is None:
                # create a new trace element and add it to the target component
                trace = ElementTree.Element('trace')
                trace.set('symbol', traceSym)
                trace.set('name', traceSym) # don't yet have different readable name
                trace.set('id', str(self.curTraceId[targetComponentId]))
                if os.path.isabs(fileName):
                    if fileName.startswith(self.home):
                        fileName = os.path.relpath(fileName, self.home)
                trace.set('file', fileName)
                self.curTraceId[targetComponentId] += 1
                targetComponent.append(trace)

            if macro == 'DESCRIBE':
                description = ElementTree.Element('description')
                description.text = args[2].strip('"')
                # parse "doxygen-style" tags out of description and apply them to trace node
                if '@percpu' in description.text:
                    trace.set('perCpu', '1')
                if '@pertid' in description.text:
                    trace.set('perTid', '1')
                if '@scope' in description.text:
                    # Forces this trace to be a scope trace even if it
                    # isn't using TRAPZ_LOG_BEGIN/END.
                    trace.set('scope', '1')
                if '@powerscope' in description.text:
                    # track cpu & power consumption in this scope
                    trace.set('powerscope', '1')
                if '@powerscope1' in description.text:
                    # track cpu & power consumption in this scope, partitioned by value in e1
                    trace.set('powerscope', 'e1')
                # print a warning on redundant descriptions
                oldDescription = trace.find('description')
                if oldDescription is not None:
                    if oldDescription.text != description.text:
                        sys.stderr.write('WARNING: description changed for trace '
                                         '%s: "%s" and "%s"\n' % (traceSym,
                                                                  oldDescription.text,
                                                                  description.text))
                        oldDescription.text = description.text
                else:
                    trace.append(description)
            if macro == 'LOG_PRINTF':
                oldFormatString = trace.get('formatString')
                newFormatString = args[4].strip('"')
                if oldFormatString and oldFormatString != newFormatString:
                    sys.stderr.write('WARNING: format string changed for trace '
                                     '%s: "%s" to "%s"\n' % (traceSym,
                                                             oldFormatString,
                                                             newFormatString))
                trace.set('formatString', newFormatString)
            elif macro in set(['LOG_ENTER', 'LOG_EXIT', 'LOG_FAIL', 'LOG_BEGIN', 'LOG_END', 'LOG_SCOPE']):
                trace.set('scope', '1')

    def WriteHeader(self, hFile, xmldir):
        """Generates header file from XML parse tree"""

        def CLangEscapedString(s):
            """Takes a string and escapes it so it can be embedded in C code"""
            return s.replace('\n', '\\n').replace('"', '\\"')

        def CLangConstCharString(name, s):
            """Takes a string and formats it as a C const char declaration
            appropriate for a header file. """
            return 'const char * const %s = "%s";\n' % (name, CLangEscapedString(s))

        def CLangMacroString(name, s):
            """Takes a string and formats it as a C macro declaration"""
            return '#define %s "%s"\n' % (name, CLangEscapedString(s))

        def FileOpenWriteClose(path, s):
            """Writes a string to a new file at path, closing the file."""
            outFile = open(path, 'w')
            outFile.write(s)
            outFile.close()

        self.hFile = hFile
        self.hFile.write(self.PRE_TEXT)
        self.Traverse(self.rootComponent, preProcess=self._WriteComponentToHeader, tagFilter='component')
        self.hFile.write(self.POST_TEXT)
        self.hFile.close()

        # Split fully decorated TRAPZ XML to header file into parts
        # and store.
        if xmldir:
            prettyXml = self.PrettyXml()
            first_part, dummy, second_part = prettyXml.partition( self.PLAT_REGISTRY_SPLIT_TEXT )
            second_part, dummy, third_part = second_part.partition( self.APP_REGISTRY_SPLIT_TEXT )

            if  second_part:
                iSplit = third_part.rfind('</trapz>')
                fourth_part = third_part[iSplit:]
                third_part = third_part[:iSplit]
            else:
                sys.stderr.write("ERROR: trapz.xml is missing marker: %s or %s\n" % \
                    (self.PLAT_REGISTRY_SPLIT_TEXT, self.APP_REGISTRY_SPLIT_TEXT))

            FileOpenWriteClose(xmldir + '/1.txt', first_part)

            # trapz -x will squirt the dynamic app symbols in between these
            FileOpenWriteClose(xmldir + '/2.txt', second_part)
            FileOpenWriteClose(xmldir + '/3.txt', third_part)

            FileOpenWriteClose(xmldir + '/4.txt', fourth_part)


    def _WriteComponentToHeader(self, path):
        """Helper function to write a single component to header"""
        element = path[-1]

        # if category is specified, enforce it
        # that means check the symbol of the top-level component and make
        # sure it matches the given category
        # XXXmunsal this is awkward
        if self.category and len(path) >= 2:
            if path[1].get('symbol') != self.category:
                return

        # indent symbol based on tree depth - to make header more readable
        indent = '  ' * (len(path)-2)
        # preprocessor symbol for this component (e.g. TRAPZ_KERNEL_DSS)
        symbol = self.FullSymbol(path)

        # %-50s left-justifies in a 50 character field (aligns everything nicely)
        self.hFile.write('#define %s%-50s %d\n' % \
                             (indent, symbol + '__ID', int(element.get('id'))))
        self.hFile.write('#define %s%-50s "%s"\n' % \
                             (indent, symbol + '__NAME', element.get('name')))
        self.hFile.write('#define %s%-50s %d\n' % \
                             (indent, symbol + '__CAT', int(element.get('cat'))))

        # now write traces for this component
        for traceElement in element.findall("trace"):
            self.hFile.write('#define %s%-50s %d\n' % \
                                 (indent, symbol + '___' + traceElement.get('symbol'),
                                  int(traceElement.get('id'))))


class SymbolTable(dict):
    """This class provides a handy dict interface to symbol table

    Example:
        s = SymbolTable('System.map')
        print s[0xdeadbeef] # helloWorld
        """

    def __new__(self, symFile):
        # if we're given a filename, open it
        try:
            symFile = open(symFile, 'r')
        except TypeError:
            pass

        symLines = symFile.read().split("\n")
        symFile.close()
        symbols = [l.split(" ") for l in symLines]
        return dict([(int(l[0], 16), l[2]) for l in symbols if len(l)==3])

######################################################
# Functions to implement individual trapztool subcommands
#
def VcdCommand(args):

    # Set up VcdWriter instance
    vcdWriter = VcdWriter(args.vcdfile)
    vcdWriter.SetTimescale(args.timescale)

    # Create XML parser + VCD helper class
    xmlVcd = TrapzXmlVcd(vcdWriter,
                         emitHierarchy=True, emitPrintfs=args.printfs,
                         emitDeltas=args.deltas, emitCounts=args.counts, emitExtras=args.extras,
                         emitTidTraces=args.tids, emitCpuTraces=args.cpus,
                         emitSched=args.sched, emitSchedCmds=args.schedCmds,
                         emitPowerReport=args.powerReport)

    if args.vcdfile == sys.stdout:
        # must not print progress while writing vcd file to stdout
        args.progress = False

    if args.progress:
        print "Parsing input"

    xmlVcd.ParseXmlOrCsv(args.logfile, args.xmlfile)

    if args.bin:
        for binFile in args.bin:
            xmlVcd.AddBinFile(binFile)

    foo = xmlVcd.GenerateEvents()
    try:
        next(foo)
    except StopIteration:
        sys.stderr.write("ERROR: no events in TRAPZ log file (try enabling components or changing log level)\n")
        sys.exit(1)

    if args.pvrtune:
        xmlVcd.ParsePvrTune(args.pvrtune, showProgress=args.progress)

    if args.logcat:
       xmlVcd.ParseLogCat(args.logcat)

    xmlVcd.AddAllEventsToVcd(showProgress=args.progress)
    xmlVcd.WriteVcd(showProgress=args.progress)

def HeaderCommand(args):
    hGen = TrapzHeaderGenerator(category=args.category, kernel_dir=args.kernel_dir)
    hGen.Parse(args.xmlfile)
    if args.scan:
        # XXXmunsal This is semi-crappy. XML contains path relative to
        # top level, but trapztool script is in labscripts/trapz. So
        # assume that we are being invoked from labscripts/trapz and
        # adjust accordingly.
        '''if args.home == sys.path[0]:
            hGen.Scan(home=os.path.normpath(os.path.join(args.home, '../..')))
        else:
            hGen.Scan(args.home)'''
        hGen.Scan(os.path.normpath(args.rootdir))
    if args.embedded_xsl:
        hGen.AddEmbeddedStylesheet(args.xslfile)
    hGen.WriteHeader(args.hfile, args.xmldir)
    # write out enumerated XML file -- this is used for VCD generation
    if args.xmlfile.endswith('.xml'):
        hGen.WritePrettyXml(args.xmlfile.replace('.xml', '-generated.xml'))

def CsvCommand(args):

    xml = TrapzXmlValidator()
    xml.ParseXmlOrCsv(args.logfile, args.xmlfile)

    if args.bin:
        for binFile in args.bin:
            xml.AddBinFile(binFile)

    events = xml.GenerateEvents()
    try:
        firstEvent = next(events)
    except StopIteration:
        sys.stderr.write("ERROR: no events in TRAPZ log file (try enabling components or changing log level)\n")
        sys.exit(1)

    offset = -(firstEvent.timestamp) if args.offset else 0

    for event in xml.GenerateEvents():
        args.outfile.write(event.PrettyCsv(xml, offset) + '\n')

def FilterCommand(args):

    def MakeFilterHelper(args):

        catIdToName = None
        if args.level is True:
            opts = ['-u']
        elif args.level is False:
            opts = ['-f']
        else:
            # level is a string for the desired log level
            # shorten to one character i.e. 'debug' -> 'd'
            opts = ['-l', args.level[0]]
            # category IDs to names
            catIdToName = {'0' : 'os',
                           '1' : 'os',
                           '2' : 'app'}

        def FilterHelper(path):
            catId = path[-1].get('cat')
            compId = path[-1].get('id')
            try:
                catId = catIdToName[catId]
            except TypeError:
                pass
            args = ['adb', 'shell', 'trapz'] + opts + [catId, compId]
            print 'Running: ' + ' '.join(args)
            result = subprocess.call(args)
            if result:
                sys.stderr.write("WARNING: adb shell failed with exit code %d\n" % result)

        return FilterHelper

    xml = TrapzXmlValidator()
    subTrapz = subprocess.Popen(['adb', 'shell', 'trapz', '-x', '0'], stdout=subprocess.PIPE)
    xml.ParseXmlOrCsv(subTrapz.stdout)
    if subTrapz.wait():
        sys.stderr.write("ERROR: adb shell returned exit code %d\n" % subTrapz.returncode)
        sys.exit(1)

    # old version has no xpath
    #components = xml.rootComponent.findall(".//component[@name='%s']" % args.name)
    components = xml.FilterComponentsByAttr( xml.rootComponent, "name", args.name )


    if len(components) == 0:
        #xpath components = xml.rootComponent.findall(".//component[@fullSymbol='%s']" % args.name)
        components = xml.FilterComponentsByAttr( xml.rootComponent, "fullSymbol", args.name )
    if len(components) == 0:
        #xpath components = xml.rootComponent.findall(".//component[@symbol='%s']" % args.name)
        components = xml.FilterComponentsByAttr( xml.rootComponent, "symbol", args.name )
    if len(components) == 0:
        sys.stderr.write("ERROR: no component found with name or symbol %s\n" % args.name)
        sys.exit(1)
    if len(components) > 1:
        sys.stderr.write("WARNING: multiple component found with name or symbol %s\n" % args.name)
        for component in components:
            sys.stderr.write("catId %s compId %s\n" % (component.get('cat'), component.get('id')))

    for component in components:
        if args.only:
            MakeFilterHelper(args)([component])
        else:
            xml.Traverse(component, preProcess=MakeFilterHelper(args), tagFilter='component')

def capture_sigint_handler(signal, frame):
    print "Capture terminated, creating data file.  Please wait."
    binCaptureFile.close()
    binCaptureFileName = binCaptureFile.name
    baseName = binCaptureFileName[:-8]
    binFileName = baseName + '.bin'
    binXmlFileName = baseName + '.xml.bin'
    binCaptureFileOutName = binCaptureFileName + '2'

    binCaptureFileIn = open(binCaptureFileName, 'r')
    binCaptureFileOut = open(binCaptureFileOutName, 'w')
    for event in TrapzEventGenerator(binCaptureFileIn):
        binCaptureFileOut.write(event.PackToString())
    binCaptureFileIn.close()
    binCaptureFileOut.close()
    binFile = open(binFileName, 'wb')
    shutil.copyfileobj(open(binXmlFileName, 'rb'), binFile)
    shutil.copyfileobj(open(binCaptureFileOutName, 'rb'), binFile)
    binFile.close()
    os.remove(binXmlFileName)
    os.remove(binCaptureFileOutName)
    os.remove(baseName + '.cap.bin')
    
    sys.exit(0)
    
def CaptureCommand(args):
    global binCaptureFile

    signal.signal(signal.SIGINT, capture_sigint_handler)

    binCaptureFileName = args.prefix + '.cap.bin'
    binCaptureFile = open(binCaptureFileName, 'w')
    binXmlFile = open(args.prefix + '.xml.bin', 'w')
    xmlFileName = args.prefix + '.xml'
    xmlFile = open(xmlFileName, 'w')
    chunkFileName = '/tmp/trapz.bin'

    # first capture Trapz metadata as XML
    cmdLine = ['adb', 'shell', 'trapz', '-x', '0']
    returnCode = subprocess.call(cmdLine, stdout=xmlFile)
    if returnCode != 0:
        sys.stderr.write('ERROR: "%s" returned exit code %d\n' % (' '.join(cmdLine), returnCode))
        sys.exit(1)

    print "Capturing Trapz data to the following files:"
    print "   Headers : ", xmlFileName
    print "   Data    : ", args.prefix + ".bin"

    firstSeq = lastSeq = -1

    # read /proc for process names
    if args.schedCmds:
        (tidName, tidParentPid) = ScrapeProc()

    while True:
        cmdLine = ['adb', 'shell', 'trapz', '-b', str(args.chunk), str(lastSeq+1),
                   '>', '/mnt/asec/tmp.bin']
        returnCode = subprocess.call(cmdLine)
        if returnCode != 0:
            sys.stderr.write('ERROR: "%s" returned exit code %d\n' % (' '.join(cmdLine), returnCode))
            sys.exit(1)

        cmdLine = ['adb', 'pull', '/mnt/asec/tmp.bin', chunkFileName]
        returnCode = subprocess.call(cmdLine)
        if returnCode != 0:
            sys.stderr.write('ERROR: "%s" returned exit code %d\n' % (' '.join(cmdLine), returnCode))
            sys.exit(1)

        chunkFile = open(chunkFileName, 'r')
        chunkData = chunkFile.read()
        chunkFile.close()
        os.remove(chunkFileName)

        nRead = len(chunkData) / TrapzEvent.STRUCT_SIZE

        if len(chunkData) == 0:
            print "Read %4d entries" % nRead
            continue

        # determine first and last sequence number of this new chunk
        firstEvent = TrapzEvent(chunkData[:TrapzEvent.STRUCT_SIZE])
        lastEvent = TrapzEvent(chunkData[-TrapzEvent.STRUCT_SIZE:])
        print "Read %4d entries" % (nRead)

        if (lastSeq < 0 & args.schedCmds):
            # first time thru, insert thread names into binary event file

            # need to parse XML header so we know component and trace IDs
            xmlFile = open(xmlFileName, 'r')
            headerTrapz = SimpleTrapz(xmlFile)
            xmlFile.close()
            (kernCatId, schedCompId, tc1TraceId) = headerTrapz.getIds("Scheduler", "TaskComm")

            for tid in tidName.keys():

                paddedTidName = tidName[tid]
                if (len(tidName[tid]) < 16):
                    paddedTidName += (16 - len(tidName[tid])) * '\000'

                # inject two TrapzEvents with the tid name of this tid
                tidNameEvent = TrapzEvent()
                tidNameEvent.timestamp = firstEvent.timestamp
                tidNameEvent.sequence = 0
                tidNameEvent.cpu = 0
                tidNameEvent.pid = tidParentPid[tid]
                tidNameEvent.tid = tid
                tidNameEvent.category = kernCatId
                tidNameEvent.compId = schedCompId
                tidNameEvent.traceId = tc1TraceId
                tidNameEvent.e1 = struct.unpack('i', paddedTidName[0:4])[0]
                tidNameEvent.e2 = struct.unpack('i', paddedTidName[4:8])[0]
                tidNameEvent.e3 = struct.unpack('i', paddedTidName[8:12])[0]
                tidNameEvent.e4 = struct.unpack('i', paddedTidName[12:16])[0]
                binXmlFile.write(tidNameEvent.PackToString())
            binXmlFile.close()

        binCaptureFile.write(chunkData)

        firstSeq = firstEvent.sequence
        lastSeq = lastEvent.sequence

        # If we're reading the whole chunk, that means the ring buffer
        # has a lot more data ... read it without sleeping.
        if nRead < args.chunk:
            time.sleep(args.sleep)

def PowerCommand(args):

    xmlFile = open(args.prefix + '.xml', 'r')
    binFile = open(args.prefix + '.bin', 'r')

    pt = PowerTrapz(xmlFile, fromSeq=args.from_seq, toSeq=args.to_seq, fromTime=args.from_time, toTime=args.to_time, n=args.n,
                    emitSecureStats=args.secure_stats, emitCpufreqStats=args.cpufreq_stats,
                    emitPowerScopes=args.power_scopes)

    binFiles = [binFile]
    if args.bin:
        binFiles += args.bin
    for f in binFiles:
        pt.AddBinFile(f)

    for event in pt.GenerateEvents(showProgress=True, sequenceWarning=True):
        pt.HandleEvent(event)

    pt.Finish(args.prefix)

if __name__ == "__main__":

    import textwrap
    import argparse

    description = "TRAPZ command line tool"

    epilog = textwrap.dedent("""
        For generic arguments and usage, invoke 'trapztool.py -h'
        For specific command arguments and usage, invoke 'trapztool.py <cmd> -h'
        Please refer to http://wiki.labcollab.net/confluence/display/KB/Trapz+User+Manual for
        more documentation and suggested workflow.""")

    parser = argparse.ArgumentParser(description=description, epilog=epilog,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('-v', '--version', action='version', version='%%(prog)s %s' % VERSION)
    # sys.path[0] is the directory where trapztool.py was invoked from
    parser.add_argument('--home', default=sys.path[0],
                        help='directory path for TRAPZ config files')
    parser.add_argument('--xmlfile', default='trapz.xml',
                        help='filename of TRAPZ XML configuration file (not the trace file)')
    parser.add_argument('--xslfile', default='trapz.xsl',
                        help='filename of TRAPZ XSLT stylesheet')
    parser.add_argument('--logcat', default=None, help='filename for logcat to merge in')
    parser.add_argument('--profile', default=None, help='filename for cProfile output')

    subparsers = parser.add_subparsers(title='Commands')

    # parser options for generating VCD files
    parserVcd = subparsers.add_parser('vcd', help='Generate VCD file from TRAPZ log file',
                                     formatter_class=argparse.RawDescriptionHelpFormatter,
                                      epilog=epilog, description=textwrap.dedent("""
        This command is used to convert TRAPZ log file generated by 'trapz -x'
        into a VCD file suitable for GTKWave or other waveform viewer.

        If the positional arguments are omitted, stdin and stdout are used instead."""))
    parserVcd.add_argument('logfile', nargs='?', type=argparse.FileType('r'),
                           default=sys.stdin, help='filename of TRAPZ log')
    parserVcd.add_argument('vcdfile', nargs='?', type=argparse.FileType('w'),
                           default=sys.stdout, help='filename for generated VCD file')
    parserVcd.add_argument('--bin', nargs='+', type=argparse.FileType('r'),
                           help='additional binary logfile(s)')
    parserVcd.add_argument('--pvrtune', type=argparse.FileType('r'),
                           help='filename for PVRTune CSV trace')
    parserVcd.add_argument('--logcat', type=argparse.FileType('r'),
                           help='filename for logcat event merge')
    parserVcd.add_argument('-t', '--timescale', choices=['s', 'ms', 'us', 'ns'],
                        default='ns', help='timescale to use for VCD file')
    parserVcd.add_argument('--no-printf', dest='printfs', action='store_false', default=True,
                            help="don't emit printf traces")
    parserVcd.add_argument('--no-delta', dest='deltas', action='store_false', default=True,
                            help="don't emit delta traces")
    parserVcd.add_argument('--no-count', dest='counts', action='store_false', default=True,
                            help="don't emit event count traces")
    parserVcd.add_argument('--no-extra', dest='extras', action='store_false', default=True,
                            help="don't emit extra traces")
    parserVcd.add_argument('--no-tids', dest='tids', action='store_false', default=True,
                            help="don't emit extra traces per TID")
    parserVcd.add_argument('--no-cpus', dest='cpus', action='store_false', default=True,
                            help="don't emit extra traces per CPU")
    parserVcd.add_argument('--no-sched', dest='sched', action='store_false', default=True,
                           help="don't add process traces based on scheduler context switches")
    # I'm not sure if this should default to be on or off.
    parserVcd.add_argument('--sched-cmds', dest='schedCmds', action='store_true', default=False,
                           help="lookup process names by PID on default ADB device")
    #parserVcd.add_argument('--no-sched-cmds', dest='schedCmds', action='store_false', default=True,
    # help="don't lookup process names by PID on default ADB device")
    parserVcd.add_argument('--no-progress', dest='progress', action='store_false', default=True,
                           help="don't show progress")
    parserVcd.add_argument('--power-report', dest='powerReport', action='store_true', default=False,
                           help="show report on thread power consumption")

    parserVcd.set_defaults(func=VcdCommand)

    # parser options for generating header file
    parserComp = subparsers.add_parser('header', help='Generate TRAPZ Component header file',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog, description=textwrap.dedent("""
        This command is used to convert the TRAPZ configuration file (manually
        written XML containing component information) into generated header files
        for the kernel and platform build. Does this by scanning C/C++ codebase"""))

    parserComp.add_argument('hfile', nargs='?', type=argparse.FileType('w'),
                            default=sys.stdout, help='filename for generated header file')
    parserComp.add_argument('xmldir', nargs='?', help='xml output dir')
    parserComp.add_argument('-c', '--category',
                            help='only traverse this top-level category (symbol)')
    parserComp.add_argument('--kernel_dir',
                            help='kernel directory')
    parserComp.add_argument('--rootdir', default='../../../../../..',
                            help='the base dir that the xml file scan attribute refers to')
    parserComp.add_argument('--no-scan', dest='scan', action='store_false', default=True,
                            help="don't scan codebase for traces")
    parserComp.add_argument('--no-embedded-xsl', dest='embedded_xsl', action='store_false', default=True,
                            help="don't embed stylesheet in XML logging")
    parserComp.set_defaults(func=HeaderCommand)

    parserComp = subparsers.add_parser('csv', help='Generate readable CSV from TRAPZ log',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog, description=textwrap.dedent("""
        This command is used to convert an XML-format TRAPZ logfile into
        a CSV file with human readable component and trace names rather than IDs.
        The XML file must begin with a TRAPZ symbol table.
        Additional binary-format TRAPZ point records may be provided (with '--bin').

        If the positional arguments are omitted, stdin and stdout are used instead."""))

    parserComp.add_argument('logfile', nargs='?', type=argparse.FileType('r'),
                            default=sys.stdin, help='filename of raw TRAPZ log (XML format only)')
    parserComp.add_argument('outfile', nargs='?', type=argparse.FileType('w'),
                            default=sys.stdout, help='filename for CSV TRAPZ log')
    parserComp.add_argument('--bin', nargs='+', type=argparse.FileType('r'),
                           help='filename of additional binary logfile(s)')
    parserComp.add_argument('--no-offset', dest='offset', action='store_false', default=True,
                            help="don't offset event timestamps to start from 0")
    parserComp.set_defaults(func=CsvCommand)

    # parser options for enabling components
    parserComp = subparsers.add_parser('enable', help='Enable TRAPZ component on current ADB device',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog, description=textwrap.dedent("""
        This command enables a TRAPZ component by name. It uses
        'adb shell' to invoke the 'trapz' command on the attached device
        in order to carry out the request."""))
    parserComp.add_argument('name', help='name (or symbol) of component to enable')
    parserComp.add_argument('--only', action='store_true', default=False,
                            help='do not automatically enable child components')
    parserComp.set_defaults(level=True)
    parserComp.set_defaults(func=FilterCommand)

    # parser options for disabling components
    parserComp = subparsers.add_parser('disable', help='Disable TRAPZ component on current ADB device',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog, description=textwrap.dedent("""
        This command disables a TRAPZ component by name. It uses
        'adb shell' to invoke the 'trapz' command on the attached device
        in order to carry out the request."""))
    parserComp.add_argument('name', help='name (or symbol) of component to disable')
    parserComp.add_argument('--only', action='store_true', default=False,
                            help='do not automatically disable child components')
    parserComp.set_defaults(level=False)
    parserComp.set_defaults(func=FilterCommand)

    # parser options for filtering components
    parserComp = subparsers.add_parser('filter', help='Set log level for component on current ADB device',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog, description=textwrap.dedent("""
        This command sets the filtering level for a TRAPZ component by name. It uses
        'adb shell' to invoke the 'trapz' command on the attached device
        in order to carry out the request."""))
    parserComp.add_argument('name', help='name or symbol of component')
    parserComp.add_argument('level', help='log level (w[arn], i[nfo], d[ebug], or v[erbose])')
    parserComp.add_argument('--only', action='store_true', default=False,
                            help='do not automatically apply to child components')
    parserComp.set_defaults(func=FilterCommand)

    # parser options for capturing extended traces
    parserComp = subparsers.add_parser('capture',
                                       help='Capture extended trace log from current ADB device',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog)
    parserComp.add_argument('prefix', help='filename prefix for XML and BIN files')
    parserComp.add_argument('--chunk', type=int, default=8192,
                            help='number of entries to download at a time')
    parserComp.add_argument('--sleep', type=float, default=1.0,
                            help='time to sleep between downloads')
    parserComp.add_argument('--no-sched-cmds', dest='schedCmds', action='store_false', default=True,
                            help="don't lookup process names by PID on default ADB device")

    parserComp.set_defaults(func=CaptureCommand)

    # parser options for capturing extended traces
    parserComp = subparsers.add_parser('power',
                                       help='Analyze power use per thread in trace log',
                                       formatter_class=argparse.RawDescriptionHelpFormatter,
                                       epilog=epilog)
    parserComp.add_argument('prefix', help='filename prefix for XML, BIN, and output (CSV) files')
    parserComp.add_argument('--bin', nargs='+', type=argparse.FileType('r'),
                           help='filename of additional binary logfile(s)')
    parserComp.add_argument('--from-seq', type=int, default=0,
                            help="Starting sequence number for analysis")
    parserComp.add_argument('--to-seq', type=int, default=sys.maxint,
                            help="Ending sequence number for analysis")

    parserComp.add_argument('--from-time', type=float, default=0,
                            help="Start time for analysis")
    parserComp.add_argument('--to-time', type=float, default=1000.0,
                            help="End time for analysis")

    parserComp.add_argument('-n', type=int, default=sys.maxint,
                            help="Count of events to analyze")
    parserComp.add_argument('--secure-stats', action='store_true', default=False,
                            help="Account for time spent in secure world")
    parserComp.add_argument('--cpufreq-stats', action='store_true', default=False,
                            help="Account for time spent in each OPP level")
    parserComp.add_argument('--power-scopes', action='store_true', default=False,
                            help="Account for time spent in the scope of tracepoints tagged with @powerscope")

    parserComp.set_defaults(func=PowerCommand)

    # parse the command line
    args = parser.parse_args()

    # prepend home directory to file names as necessary
    if not os.path.dirname(args.xmlfile) or not os.path.exists(args.xmlfile):
        args.xmlfile = os.path.join(args.home, args.xmlfile)
    if not os.path.dirname(args.xslfile) or not os.path.exists(args.xslfile):
        args.xslfile = os.path.join(args.home, args.xslfile)

    # invoke the subcommand function
    if args.profile:
        # save profiling data to filename in args.profile
        import cProfile as profile
        profile.run("args.func(args)", args.profile)
    else:
        args.func(args)
